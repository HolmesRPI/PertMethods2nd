function chainS0

%  solve IVP using MATLAB routines
%         y' = f(t,y)  with   y(0) = y0        
%  where y = (y1, y2, y3 , ..., yn) is an n-vector


% clear all previous variables and plots
clear *
clf

% get(gcf)
set(gcf,'Position', [1591 816 675 360]);
hold on

tmax=30;
N=100;

%  initial values
% y(odd) = y_i	y(even) = v_i

% point load
y0=zeros(4*N-2,1);
y0(2*N-1)=1;

% cosh
ep=0.1;
ni=-N;
for j=1:2:4*N-2
	ni=ni+1;
%	y0(j)=cos(ni*pi)/cosh(ni*0.26);
%	y0(j+1)=0;
%	y0(j)=cos(ni*pi)*Amp(ep*ni);
%	y0(j+1)=sin(ni*pi)*Amp(ep*ni)*2*(1+1.5*ep*Amp(ep*ni)^2);
	y0(j)=cos(ni*pi)*Amp(ep*ni);
	y0(j+1)=0;
end;

x=linspace(-N+1,N-1,2*N-1);


%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0); 
%[t,y] = ode23s(@rhs,[0 tmax],y0); 

nt=size(t);

for it=1:nt

jj=0;
sol=zeros(2*N-1,1);
for j=1:2:4*N-2
	jj=jj+1;
	sol(jj)=y(it,j);
end;

x=linspace(-N+1,N-1,2*N-1);
clf
hold on
grid on
box on
ylabel('y - axis','FontSize',14,'FontWeight','bold')
xlabel('n - axis','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14); 
%t0=round(10*t(nt1))/10;
t0=round(t(it));
say=['t = ', num2str(t0)]; 
text(100,0.5,say,'FontSize',14,'FontWeight','bold')
%	axis([-50 50 -0.2 0.2]);
axis([-N N -2 2]);
	plot(x,sol,'ko','MarkerSize',6,'LineWidth',1.2)
	plot(x,sol,'--r','LineWidth',1.3)
%	text(30,1.2,say,'FontSize',18,'FontWeight','bold')
%	set(gca,'ytick',[-1.5 -1 -0.5 0 0.5 1 1.5]);
%	set(gca,'xtick',[-40 -30 -20 -10 0 10 20 30 40]);
%set(gca,'xtick',[0 100 200 300 400 500]);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 

F(it) = getframe(gcf);
hold off
%pause
end

%movie(F)
%movie2avi(F,'chainSS0.avi');

%  define amp function
function g=Amp(x)
x0=5;
if(x^2<x0^2)
	g=1-(x/x0)^2;
else
	g=0;
end

%  define f(t,y)
function dy=rhs(t,y)
% y(odd) = y_i	y(even) = v_i
N=100;
ep=0.1;
a=1;
jj=1;
dy=zeros(4*N-2,1);
dy(jj)=y(jj+1);
dy(jj+1)=a*(y(jj+2)-2*y(jj)) + ep*(y(jj+2)-y(jj))^3 - ep*(y(jj) )^3;
for j=2:2*N-2
	jj=jj+2;
	dy(jj)=y(jj+1);
	dy(jj+1)=a*(y(jj+2)-2*y(jj)+y(jj-2)) + ep*(y(jj+2)-y(jj))^3 - ep*(y(jj)-y(jj-2))^3;
end;
jj=jj+2;
dy(jj)=y(jj+1);
dy(jj+1)=a*(-2*y(jj)+y(jj-2)) + ep*( -y(jj))^3 - ep*(y(jj)-y(jj-2))^3;
%pause





















