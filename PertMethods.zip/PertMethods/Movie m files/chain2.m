function chain2

%  solve IVP using MATLAB routines
%         y' = f(t,y)  with   y(0) = y0        
%  where y = (y1, y2, y3 , ..., yn) is an n-vector


% clear all previous variables and plots
clear *
clf

% get(gcf)
set(gcf,'Position', [1051 933 929 424]);
hold on

tmax=160;
N=200;

%  initial values
y0=zeros(4*N-2,1);
y0(2*N-1)=1;

%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0);  titleX='ode45';
%[t,y] = ode23s(@rhs,[0 tmax],y0);  titleX='ode23s';

nt=size(t)
tN=-0.0001;
iframe=0;
for it=1:nt(1)

if t(it)>tN
	iframe=iframe+1
	jj=0;
	sol=zeros(2*N-1,1);
	for j=1:2:4*N-2
		jj=jj+1;
		sol(jj)=y(it,j);
	end;
	x=linspace(-N+1,N-1,2*N-1);
	hold on
	plot(x,sol,'--r')
	plot(x,sol,'ko','MarkerSize',5)
	grid on
	box on
	ylabel('y - axis','FontSize',14,'FontWeight','bold')
	set(gca,'FontSize',14); 
	t0=round(1*t(it))/1;
	say=['t = ', num2str(t0)]; 
	text(100,0.85,say,'FontSize',18,'FontWeight','bold')
	axis([-N N -0.4 1]);

	% commands to label each axes
	xlabel('i-axis','FontSize',14,'FontWeight','bold')
	ylabel('y - axis','FontSize',14,'FontWeight','bold')

	%set(gca,'xtick',[0 100 200 300 400 500]);
	% Set the fontsize to 14 for the plot
	set(gca,'FontSize',14); 
	% Set legend font to 14/bold                            		
	set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 
	hold off

	% make movie frame
	F(iframe) = getframe(gcf);
	clf

	tN=tN+1;
end
end


% produce movie file
movie2avi(F,'wave0.avi')



%  define f(t,y)
function dy=rhs(t,y)
% y(odd) = y_i	y(even) = v_i
N=200;
a=1;
jj=1;
dy=zeros(4*N-2,1);
dy(jj)=y(jj+1);
dy(jj+1)=a*(y(jj+2)-2*y(jj));
for j=2:2*N-2
	jj=jj+2;
	dy(jj)=y(jj+1);
	dy(jj+1)=a*(y(jj+2)-2*y(jj)+y(jj-2));
end;
jj=jj+2;
dy(jj)=y(jj+1);
dy(jj+1)=a*(-2*y(jj)+y(jj-2));
%pause





















