function fig15

clf

ne=200;
ep=linspace(0.001,1,ne);

% get(gcf)
set(gcf,'Position', [1041 771 548 229]);

for ie=1:ne
	y(ie)=-ep(ie)+sqrt(1+ep(ie)^2);
	ya(ie)=1-ep(ie);
end;

semilogx(ep,y,'-k','Linewidth',1)
hold on
semilogx(ep,ya,'--k','Linewidth',1.1)

box on
grid on
%axis([0 80 -1 1])
loc='SouthWest';

xlabel('\epsilon-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact Solution',' Asymptotic Expansion','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

