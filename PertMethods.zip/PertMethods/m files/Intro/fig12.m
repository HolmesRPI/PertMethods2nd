function fig12

clf

nx=200;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

ep=0.01;
for ix=1:nx
	y(ix)=x(ix)+exp(-x(ix)/ep);
end;

hold on
box on
grid on

%plot(x,y,'--','Linewidth',1)
%plot(x,x,'-r','Linewidth',1)
plot(x,y,'--k','Linewidth',1.1)
plot(x,x,'-k','Linewidth',1)

%axis([0 80 -1 1])
loc='SouthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Function','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Function',' Asymptotic Approximation','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

