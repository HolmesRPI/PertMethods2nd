function fig13

clf

% Series values
load bessels.txt
n=bessels(:,1);
ys=bessels(:,2);

% Asy approx values
load bessela.txt
nn=bessela(:,1);
ya=bessela(:,2);

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

semilogy(n,ys,'--k','Linewidth',1.1)
hold on
semilogy(nn,ya,'-k','Linewidth',1)

box on
grid on
axis([0 100 1e-16 1e8])
loc='North';
%loc='SouthEast';

xlabel('Number of Terms','FontSize',14,'FontWeight','bold')
ylabel('Error','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
set(gca,'ytick',[1e-16 1e-8 1 1e8]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
legend(' Series',' Asymptotic Approximation','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off



