function fig114

clf

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

nx=1000;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [844 532 667 399]);

ep=0.01;
alpha=-1+sqrt(1-2*ep);  beta=-1-sqrt(1-2*ep);
for ix=1:nx
	y(ix)=exp(alpha*x(ix)/ep)+exp(beta*x(ix)/ep);
	ya1(ix)=exp(-x(ix))+exp(-2*x(ix)/ep);
	ya2(ix)=exp(-x(ix));
end;

subplot(2,1,1)
plot(x,y,'--','Linewidth',1)
hold on
plot(x,ya2,'-.','Linewidth',1)
plot(x,ya1,'-','Linewidth',1)

box on
grid on
axis([-0.03 1 0 2])
loc='NorthEast';
%loc='SouthWest';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact',' Nonuniform',' Uniform','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


subplot(2,1,2)

plot(x,y,'--','Linewidth',1)
hold on
plot(x,ya2,'-.','Linewidth',1.2)
plot(x,ya1,'-','Linewidth',1)

box on
grid on
axis([-0.005 0.05 0.8 2])

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'ytick',[1 2]);
set(gca,'FontSize',14);
legend(' Exact',' Nonuniform',' Uniform','Location','EastOutside');
set(findobj(gcf,'tag','legend'),'FontSize',14); 
