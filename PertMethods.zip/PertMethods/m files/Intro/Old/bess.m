function bess

%  reads in data from FORTRAN codes for PCGM and CGM

% clear all previous variables and plots
clear *
clf

%  read in data from FORTRAN programs
load bessdata.txt

n=bessdata(:,1);
ssum=bessdata(:,2);
asy=bessdata(:,3);

% get(gcf)
%set(gcf,'Position', [7  477 515 307]);

% plot solution
semilogy(n,ssum,'--k')
hold on
grid on
semilogy(n,asy,'k')


axis([0 100 1.0e-14 1e7]);
%set(gca,'XTick',[0 0.2 0.4 0.6 0.8 1.0])
set(gca,'YTick',[1e-14 1e-9 1e-4 10 1e6])

% define axes used in plot
xlabel('Size of A','FontSize',14,'FontWeight','bold')
ylabel('Steps','FontSize',14,'FontWeight','bold')

% have MATLAB use certain plot options (all are optional)
set(gca,'MinorGridLineStyle','none')
set(gca,'FontSize',14);
legend(' Series',' Asymptotic Approimation','Location','North');
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 






