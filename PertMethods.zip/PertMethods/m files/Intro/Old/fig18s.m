function fig18s

clf

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

nx=1000;
xe=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [844 645 679 286]);

ep=0.01;
alpha=-1+sqrt(1-2*ep);  beta=-1-sqrt(1-2*ep);
for ix=1:nx
	x(ix) = 10^(4*xe(ix)-4);
	y(ix)=exp(alpha*x(ix)/ep)+exp(beta*x(ix)/ep);
	ya1(ix)=exp(-x(ix))+exp(-2*x(ix)/ep);
	ya2(ix)=exp(-x(ix));
end;

semilogx(x,y,'--','Linewidth',1)
hold on
semilogx(x,ya2,'-.','Linewidth',1.2)
semilogx(x,ya1,'-','Linewidth',1)

box on
grid on
%axis([-0.03 1 0 2])
loc='NorthEast';
%loc='SouthWest';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'MinorGridLineStyle','none')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.2 0.4 0.6]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
legend(' Exact',' Nonuniform',' Uniform','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

