function fig12

clf

nx=200;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

ep=0.01;
for ix=1:nx
	y(ix)=x(ix)+exp(-x(ix)/ep);
end;

hold on
box on
grid on

plot(x,y,'--','Linewidth',1)
plot(x,x,'-r','Linewidth',1)


%axis([0 80 -1 1])
%loc='NorthWest';
loc='SouthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Function','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.5]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
legend(' Function',' Asymptotic Approximation','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

