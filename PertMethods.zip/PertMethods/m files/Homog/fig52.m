function fig52

clf

% get(gcf)
set(gcf,'Position', [1869 834 573 199]);

hold on
box on
grid on

nx=200;
x=linspace(0,1,nx);
a=-0.1; b=0.1;
ep=0.01;

for ix=1:nx
	g=exp(4*x(ix)*(x(ix)-1));
	d(ix)=1/(1+a*x(ix)+b*g*cos(x(ix)/ep));
	d2(ix)=1/(1+a*x(ix)+b*g);
end;

hold on
box on
grid on

plot(x,d,'-','Linewidth',1.2)

axis([0 1 0.9 1.301])

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('D','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
set(findobj(gcf,'tag','legend'),'FontSize',14); 
hold off


figure

% get(gcf)
set(gcf,'Position', [1868 1153  573 199]);

hold on
box on
grid on

s=-1;
xx=linspace(0,1,17);
for i=1:16
	s=-s;
	g=exp(4*xx(i)*(xx(i)-1));
	d2=1/(1+a*xx(i)+b*g*s);
	plot([xx(i) xx(i+1)], [d2 d2],'Linewidth',1.3);
end;

hold on
box on
grid on


ylabel('D','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
