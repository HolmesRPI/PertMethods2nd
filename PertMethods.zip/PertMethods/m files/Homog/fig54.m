function fig54

clf

% get(gcf)
set(gcf,'Position', [1868 1153  573 199]);

hold on
box on
grid on

nx=400;
x=linspace(0,1,nx);
a=0.0; b=0.83;

hold on
box on
grid on
ep=0.01;
for ix=1:nx
	g=exp(4*x(ix)*(x(ix)-1));
	d(ix)=1/(1+a*x(ix)+b*g*cos(x(ix)/ep));
	d2(ix)=1/(1+a*x(ix));
	d3(ix)=1/sqrt( (1+a*x(ix))^2 - (b*g)^2 );
end;

plot(x,d,'-k','Linewidth',1)

plot(x,d3,'--r','Linewidth',1.3)

plot(x,d2,'-.b','Linewidth',1.3)


xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('D','FontSize',14,'FontWeight','bold')

axis([0 1 0.5 4])

set(gca,'FontSize',14);
loc='North';
legend(' D',' D_a',' D_h','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 































