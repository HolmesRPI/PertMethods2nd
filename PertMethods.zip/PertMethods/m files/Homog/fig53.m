function fig53

clf

% get(gcf)
set(gcf,'Position', [1868 1153  573 199]);

hold on
box on
grid on

nx=400;
x=linspace(0,1,nx);
a=0; b=0.83;
ep1=0.1;
ep2=0.01;
g=1;
for ix=1:nx
	u0(ix)=x(ix);
	uu1(ix)=(x(ix)+b*ep1*sin(x(ix)/ep1))/(1+b*ep1*sin(1/ep1));
	uu2(ix)=(x(ix)+b*ep2*sin(x(ix)/ep2))/(1+b*ep2*sin(1/ep2));
end;

hold on
box on
grid on

plot(x,u0,'-k','Linewidth',1)
plot(x,uu1,'--b','Linewidth',1.3)
plot(x,uu2,'-.r','Linewidth',1.3)

%axis([0 80 -2 2])
loc='NorthWest';
%loc='SouthWest';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' u_0(x)',' Exact (\epsilon = 0.1)',' Exact (\epsilon = 0.01)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off























