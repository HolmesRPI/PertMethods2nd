function fig56

clf

% get(gcf)
set(gcf,'Position', [1868 1153  573 199]);

hold on
box on
grid on

nx=100;
x1=linspace(0,1,nx);
x2=1+x1;
for ix=1:nx
	u1(ix)=1+abs(sin(pi*x1(ix)));
	u2(ix)=0.5*sin(2*pi*x1(ix));
end;

hold on
box on
grid on

plot(x1,u1,'-','Linewidth',1)
plot(x1,u2,'-','Linewidth',1)
plot(x2,u1,'--','Linewidth',1)
plot(x2,u2,'--','Linewidth',1)

axis([0 2 -0.5 2])

xlabel('y-axis','FontSize',14,'FontWeight','bold')
ylabel('w-axis','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
hold off























