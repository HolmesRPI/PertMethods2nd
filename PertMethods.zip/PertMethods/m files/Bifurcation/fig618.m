function fig618

%  use    fix_lines('untitled.eps');   to fix dotted line

% clear all previous variables and plots
clear *
clf

lam=0.1; 
tmax=10*pi;

% get(gcf)
%set(gcf,'Position', [778 481 487 276]);
set(gcf,'Position', [1992 1134 487 276]);

hold on
axis equal
n=100;
th=linspace(0,2*pi,n);
for i=1:n
	ys(i)=2*cos(th(i));
	vs(i)=2*sin(th(i));
end;

na=200;
c=4/3;  
ta=linspace(0,tmax,na);
for i=1:na
	cc = sqrt( c/( c + 4*exp(-lam*ta(i)) ));
	ya(i) = 2*cc*cos(ta(i));
	va(i) = -2*cc*sin(ta(i));
end;


%  initial values
y10=1; y20=0;
y0=[y10 y20];
%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0);  


plot(y(:,1),y(:,2),'-r','LineWidth',1)
plot(ya,va,'--','LineWidth',1)
plot(ys,vs,'-.k','LineWidth',1.5)

axis([-2.5 2.5 -2.5 2.5]);

i=10;  ii=i+2;
arrowhead([ya(i) ya(ii)],[va(i) va(ii)],[],[1 1.2],2);

i=110;  ii=i+2;
arrowhead([ya(i) ya(ii)],[va(i) va(ii)],[],[1 1.2],2);

% commands to label each axes
xlabel('y-axis','FontSize',10,'FontWeight','bold')
ylabel('v-axis','FontSize',10,'FontWeight','bold')
grid on

% command to put legend into plot
loc='EastOutside';
legend(' Numerical',' Asymptotic',' Limit Cycle','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',10); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',10,'FontWeight','bold'); 

hold off


%  define f1(t,y)
function dy=rhs(t,y)
dy=zeros(2,1);
lam=0.1; 
dy(1) = y(2);
dy(2) = lam*(1-y(1)^2)*y(2)-y(1);









