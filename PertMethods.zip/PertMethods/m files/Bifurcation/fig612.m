function fig612

%  save figure as untitled.eps and then use    fix_lines('untitled.eps');   to fix dotted line

% clear all previous variables and plots
clear *
clf

tmax=0.05;
ep=0.01; 
% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

n=100;
ys=linspace(1,2,n);
for i=1:n
	ts(i)=ys(i)-ys(i)^3/3;
end;

na=100;
ta=linspace(0,tmax,na);
for i=1:na
	ya(i)=2*sqrt(12-3*exp(-2*ta(i)/ep))/(4-exp(-2*ta(i)/ep));
end;

%  initial values
y10=2;  
y0=[y10];

%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0);  

hold on

plot(t,y,'-b','LineWidth',1)
plot(ta,ya,'--r','LineWidth',1.2)
plot(ts,ys,':k','LineWidth',1.5)

axis([0 tmax 1.7 2]);
% commands to label each axes
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
grid on

% command to put legend into plot
loc='NorthEast';
legend(' Numerical',' Y_0',' y_0','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off

%  define f(t,y)
function dy=rhs(t,y)
dy=zeros(1,1);
ep=0.01; 
dy(1) = ( y(1) - y(1)^3/3 - t )/ep;










