function fig625


clf

% get(gcf)
set(gcf,'Position', [1000 1231 663 247]);


%q=1/2-x0+(ep/a)*log( (1-g*exp(-lambda*t))/(1+g*exp(-lambda*t)));

a=1;  ep=0.01;  x0=0.25;
k=a*(1/2-x0)/ep;
g=(1-exp(-k))/(1+exp(-k));
lambda=2*a^2*exp(-a/(2*ep))/ep;


nt=200;
dt=linspace(-3,25,nt);

for it=1:nt
	t(it)=10^(dt(it));
	if(t(it)<10^5)
		q(it)=a*exp(-a*x0/ep)*t(it);
	else
		q(it)=1/2-x0+(ep/a)*log( (1-g*exp(-lambda*t(it)))/(1+g*exp(-lambda*t(it))));
	end

end

loglog(t,q,'Linewidth',1.1)
hold on
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('q-axis','FontSize',14,'FontWeight','bold')
box on
grid on
x1=10^(-5); x2=10^(25); y1=10^(-15); y2=1;
axis([x1 x2 y1 y2]);

% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 



