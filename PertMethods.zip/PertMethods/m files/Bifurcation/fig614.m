function fig614

% clear all previous variables and plots
clear *
clf

tmax=1;
ep=0.001; 

% get(gcf)
%set(gcf,'Position', [805 516 578 232]);
set(gcf,'Position', [1896 1238 573 199]);

% steady state
ns=100;
ys=linspace(-3,2,ns);
for i=1:ns
	ts(i)=ys(i)-ys(i)^3/3;
end;

% asy sol
na=200;
t0=2/3+2.338*ep^(2/3);
ta=linspace(0.66,0.7,na);
yold=1;
A0=-3/4;
for i=1:na
	tt=(ta(i)-t0)/ep;
	ff=exp(-3*(tt+A0)-1);
	q=fzero(@(x)x*exp(x)-ff,yold);
	ya(i)=(-2+q)/(1+q);
	yold=ya(i);
end;

%  initial values
y10=2;  
y0=[y10];

%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0);  

hold on

plot(t,y,'--','LineWidth',1.1)
plot(ta,ya,'-r','LineWidth',1)
%plot(ts,ys,':','LineWidth',2)

xp1=2/3; yp1=1;
plot(xp1,yp1,'.k','LineWidth',1,'MarkerSize',24)

axis([0.66 0.7 -2.2 1.3]);
% commands to label each axes
xlabel('t-axis','FontSize',12,'FontWeight','bold')
ylabel('Solution','FontSize',12,'FontWeight','bold')
grid on

set(gca,'XTickLabel',{'0.66';'0.67';'0.68';'0.69';'0.7'})

% command to put legend into plot
loc='SouthWest';
legend(' Numerical',' Interior Layer',' Bifurcation Point','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 12 for the plot
set(gca,'FontSize',12); 
% Set legend font to 12/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',12,'FontWeight','bold'); 

hold off

%  define f(t,y)
function dy=rhs(t,y)
dy=zeros(1,1);
ep=0.001; 
dy(1) = ( y(1) - y(1)^3/3 - t )/ep;










