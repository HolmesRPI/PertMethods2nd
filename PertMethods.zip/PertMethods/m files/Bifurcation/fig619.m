function fig619

clear *
clf

% get(gcf)
set(gcf,'Position', [850 383 451 349]);

n=30;
lam=linspace(0,1,n);
theta=linspace(0,2*pi,n);
for ir=1:n
	for it=1:n
		r=sqrt( lam(ir)*(1-lam(ir)) );
		x(ir,it)=r*cos(theta(it));
		y(ir,it)=r*sin(theta(it));
		z(ir,it)=lam(ir);
end;
end;

hold on
plot3([0 0],[1 1.2],[0 0],'k','Linewidth',1)
plot3([0 0],[-0.2 0],[0 0],'k','Linewidth',1)
plot3([-0.6 0.6],[0 0],[0 0],'k','Linewidth',1)
plot3([0 0],[0 0],[-0.55 0.6],'k','Linewidth',1)

text(0.1,1.2,-0.08,'\lambda','FontSize',20)
text(0.5,0,-0.1,'y','FontSize',20)
text(0.0,-0.13,0.55,'v','FontSize',20)

axis off

surf(x,z,y)
colormap(pink)
axis([-0.5 0.5  -0.3 1.3 -0.5 0.5])

view(110, 22);
% Set the fontsize to 14 for the plot
set(gca,'FontSize',16); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  

hold off








