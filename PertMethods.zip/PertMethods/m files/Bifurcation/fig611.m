function fig611

%  use    fix_lines('untitled.eps');   to fix dotted line
% note modified file is put into Holmes/Documents/MATLAB

% clear all previous variables and plots

clear *
clf

% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

n=100;
y=linspace(-3,3,n);
for i=1:n
	lam(i)=y(i)-y(i)^3/3;
end;

%  initial values
y10=2;  
y0=[y10];
tmax=1;

%  calculate solution using a MATLAB routine
[t1,y1] = ode45(@rhs1,[0 tmax],y0);  
[t2,y2] = ode45(@rhs2,[0 tmax],y0);  

hold on
plot(lam,y,':','LineWidth',1.6)
%plot(lam,y,'o','LineWidth',2)
plot(t1,y1,'-','LineWidth',1)
plot(t2,y2,'--','LineWidth',1)

axis([0 1 -2.2 2]);
% commands to label each axes
xlabel('t-axis','FontSize',12,'FontWeight','bold')
ylabel('Solution','FontSize',12,'FontWeight','bold')
grid on

set(gca,'xtick',[0 0.2 0.4 0.6 0.8 1]);

% command to put legend into plot
loc='SouthWest';
legend(' y_0',' y (\epsilon = 0.01)',' y (\epsilon = 0.001)','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',12); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',12,'FontWeight','bold'); 

hold off

%  define f1(t,y)
function dy=rhs1(t,y)
dy=zeros(1,1);
ep=0.01; 
dy(1) = ( y(1) - y(1)^3/3 - t )/ep;

%  define f2(t,y)
function dy=rhs2(t,y)
dy=zeros(1,1);
ep=0.001; 
dy(1) = ( y(1) - y(1)^3/3 - t )/ep;











