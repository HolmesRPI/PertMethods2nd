function fig610

% clear all previous variables and plots
clear *
clf

% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

n=100;
y=linspace(-3,3,n);
for i=1:n
	lam(i)=y(i)-y(i)^3/3;
end;

hold on
plot(lam,y,'-','LineWidth',1)

axis([-2 2 -3 3]);
% commands to label each axes
xlabel('\lambda','FontSize',14,'FontWeight','bold')
ylabel('Steady State','FontSize',14,'FontWeight','bold')
grid on

xp1=2/3; yp1=1;
plot(xp1,yp1,'.b','LineWidth',1,'MarkerSize',24)
text(0.8,1,'(2/3, 1)','FontSize',14,'FontWeight','bold')

xp1=-2/3; yp1=-1;
plot(xp1,yp1,'.b','LineWidth',1,'MarkerSize',24)
text(-1.38,-1,'(-2/3, -1)','FontSize',14,'FontWeight','bold')

set(gca,'ytick',[-3  -1  1 3]);

% command to put legend into plot
loc='NorthWest';
%legend(' \Omega = 40 cps',' \Omega = 30 cps','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off












