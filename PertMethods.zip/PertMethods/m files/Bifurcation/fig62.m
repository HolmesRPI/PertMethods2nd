function fig62

%  solve IVP using MATLAB routines
%         y' = f(t,y)  with   y(0) = y0        
%  where y = (y1, y2, y3 , ..., yn) is an n-vector

% clear all previous variables and plots
clear *
clf

% get(gcf)
set(gcf,'Position', [805 516 578 232]);
hold on

for i=1:2
	% time interval
	tmax=20;

	if i==1
		y10=0; y20=1; 
		y0=[y10 y20];
		i1=30; ii1=i1+1;
		i2=50; ii2=i2+1;
	else
		y10=2; y20=0; 
		y0=[y10 y20];
		i1=30; ii1=i1+1;
		i2=50; ii2=i2+1;
	end

	%  calculate solution using a MATLAB routine
	[t,y] = ode45(@rhs,[0 tmax],y0);  
	%[t,y] = ode23s(@rhs,[0 tmax],y0); 
	plot(y(:,1),y(:,2),'k')
	arrowhead([y(i1,1) y(ii1,1)],[y(i1,2) y(ii1,2)],'k',[1.4 1.6]);
	arrowhead([y(i2,1) y(ii2,1)],[y(i2,2) y(ii2,2)],'k',[1.4 1.6]);
end;

axis([-1.5 2 -2 1]);
% commands to label each axes
xlabel('y-axis','FontSize',14,'FontWeight','bold')
ylabel('v-axis','FontSize',14,'FontWeight','bold')
grid on
% command to put legend into plot
%legend(' y_1',' y_2',4);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off

%  define f(t,y)
function dy=rhs(t,y)
dy=zeros(2,1);
b=0.25; lam=1;
dy(1) = y(2);
dy(2) = -2*b*y(2) + lam*y(1) - y(1)^3;













