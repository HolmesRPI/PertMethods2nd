function fig616

clf

xL=-4; 
xR=4; 

nx = 200;
x=linspace(xL,xR,nx); 
a=1; b=2.2; c=3;
for ix=1:nx
	y(ix) = x(ix)*(x(ix)^2-a^2)*(x(ix)^2-b^2)*(x(ix)^2-c^2);
end;


clf
% get(gcf)
set(gcf,'Position', [899 616 685 276]);

plot(x,y,'LineWidth',1.2)
hold on
plot([-4 4], [0 0],'--k','LineWidth',1)
plot([0 0], [-200 200],'--k','LineWidth',1)
%grid on
box on
axis([-4 4 -110 110])

set(gca,'YTick',[-200 0 200])
set(gca,'XTick',[-10 0 10])

xlabel('y-axis','FontSize',14,'FontWeight','bold')
ylabel('F-axis','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
hold off




























