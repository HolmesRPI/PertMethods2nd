function fig624

% plot solutions of
%        u_t + u*u_x = ep*u_xx     for xL < x < xR  
% where 
%          u(xL,t) = a0 ,  u(xR,t) = b0,  u(x,0) = phi(x)

clf
% get(gcf)
%set(gcf,'Position', [1925 1095 573 199]);

load data_1.txt
load data_10000.txt

x1=data_1(:,1);
u1=data_1(:,2);

x10000=data_10000(:,1);
u10000=data_10000(:,2);

subaxis(4,1,1,1,'MT',0.005,'MB',0.1,'MR',0.01,'ML',0.06,'P',0.02);
hold on
plot([0 0.249999 0.25 1],[1 1 -1 -1],'Linewidth',1.2);

xt=0.05; yt=0.35;
say=['t = 0']; 
text(xt,yt,say,'FontSize',12)

grid on
box on
axis([0 1 -1.3 1.3])
%xlabel('x-axis','FontSize',12,'FontWeight','bold')
ylabel('u-axis','FontSize',12,'FontWeight','bold')
set(gca,'FontSize',12);
hold off

subaxis(4,1,1,2);
plot(x1,u1,'Linewidth',1.2);
hold on

xt=0.05; yt=0.35;
say=['t = 1']; 
text(xt,yt,say,'FontSize',12)

grid on
box on
axis([0 1 -1.3 1.3])
%xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('u-axis','FontSize',12,'FontWeight','bold')
set(gca,'FontSize',12);
hold off

subaxis(4,1,1,3);
plot(x10000,u10000,'Linewidth',1.2);
hold on

xt=0.05; yt=0.35;
say=['t = 10000']; 
text(xt,yt,say,'FontSize',12)

grid on
box on
axis([0 1 -1.3 1.3])
%xlabel('x-axis','FontSize',12,'FontWeight','bold')
ylabel('u-axis','FontSize',12,'FontWeight','bold')
set(gca,'FontSize',12);
hold off

subaxis(4,1,1,4);
nx=200;
ep=0.01;
a=1;
x=linspace(0,1,nx);
for ix=1:nx
	r=a*(x(ix)-0.5)/ep;
	ui(ix)=a*(1-exp( r ))/(1+exp( r ));
end

plot(x,ui,'Linewidth',1.2)
hold on

xt=0.05; yt=0.35;
say=['t = \infty']; 
text(xt,yt,say,'FontSize',12)

grid on
box on
axis([0 1 -1.3 1.3])
xlabel('x-axis','FontSize',12,'FontWeight','bold')
ylabel('u-axis','FontSize',12,'FontWeight','bold')
set(gca,'FontSize',12);
hold off



















