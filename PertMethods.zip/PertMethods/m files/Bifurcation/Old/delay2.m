


function delay2

N=50;
T=1;
r=0.5*pi*1.1;
nt=400;

t=linspace(0,(N+1)*T,nt);

y=ones(1,nt);
for it=2:nt
	for n=0:N
		y(it) = y(it) + h(t(it)-n*T)*(-r*(t(it)-n*T))^(n+1)/factorial(n+1);
	end
end;

size(t)
size(y)

plot(t,y)
xlabel('time t');
ylabel('solution y');


function g = h(t)
g=0.5*(sign(t)+1);

