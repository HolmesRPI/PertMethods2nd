function delay0

%DDEX1  Example 1 for DDE23.
%   The differential equations
%
%        y'_1(t) = y_1(t-1)  
%        y'_2(t) = y_1(t-1)+y_2(t-0.2)
%        y'_3(t) = y_2(t)
%
%   are solved on [0, 5] with history y_1(t) = 1, y_2(t) = 1, y_3(t) = 1 for
%   t <= 0. 
%
%   The lags are specified as a vector [1, 0.2], the delay differential
%   equations are coded in the subfunction DDEX1DE, and the history is
%   evaluated by the function DDEX1HIST. Because the history is constant it
%   could be supplied as a vector:
%       sol = dde23(@ddex1de,[1, 0.2],ones(3,1),[0, 5]);
%




tmax=100000;
T=15.32;


options = ddeset('RelTol',1e-11);

sol = dde23(@ddex1de,[T],@ddex1hist,[0, tmax],options);
plot(sol.x,sol.y)
xlabel('time t');
ylabel('solution y');


% find relative min and max points
si=size(sol.x);
it_min=1; it_max=1;
for it=2:si(2)-1
	if (sol.y(it-1)>sol.y(it)) && (sol.y(it)<sol.y(it+1))
		it_min=it;
	end
	if (sol.y(it-1)<sol.y(it)) && (sol.y(it)>sol.y(it+1))
		it_max=it;
	end
end

% amp
amp = (sol.y(it_max)-sol.y(it_min))/2


% --------------------------------------------------------------------------

function s = ddex1hist(t)
% Constant history function for DDEX1.
s = ones(1);

% --------------------------------------------------------------------------

function dydt = ddex1de(t,y,Z)
% Differential equations function for DDEX1.
mu=0.25;
ylag1 = Z(:,1);
dydt = -mu*y(1) + exp(-ylag1(1));














