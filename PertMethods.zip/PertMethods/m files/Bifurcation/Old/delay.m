function delay

%DDEX1  Example 1 for DDE23.
%   The differential equations
%
%        y'_1(t) = y_1(t-1)  
%        y'_2(t) = y_1(t-1)+y_2(t-0.2)
%        y'_3(t) = y_2(t)
%
%   are solved on [0, 5] with history y_1(t) = 1, y_2(t) = 1, y_3(t) = 1 for
%   t <= 0. 
%
%   The lags are specified as a vector [1, 0.2], the delay differential
%   equations are coded in the subfunction DDEX1DE, and the history is
%   evaluated by the function DDEX1HIST. Because the history is constant it
%   could be supplied as a vector:
%       sol = dde23(@ddex1de,[1, 0.2],ones(3,1),[0, 5]);
%
%   See also DDE23, FUNCTION_HANDLE.



tmax=10000
T=1.0001*pi/2;
%T=0.99999999*pi/2;

options = ddeset('RelTol',1e-6);

sol = dde23(@ddex1de,[T],@ddex1hist,[0, tmax],options);
plot(sol.x,sol.y)
xlabel('time t');
ylabel('solution y');

% find distance between relative min points
si=size(sol.x);
it_min=1;
for it=2:si(2)-1
	if (sol.y(it-1)>sol.y(it)) && (sol.y(it)<sol.y(it+1))
		it_m=it;
		dtmin=sol.x(it_m)-sol.x(it_min);
		it_min=it_m;
		amp=1-sol.y(it_m);
	end
end

% period comparison
dtmin
ep2=T-pi/2;
%tep=-6*(1+5*pi^2/(2+3*pi))/(5*(4+pi^2));
%tep=-12/(2+3*pi);
tep=-6/(3*pi-2);
per=2*pi/(1+ep2*tep)

% amp comparison
amp
%ampp=2*sqrt(10/(2+3*pi))*sqrt(T-pi/2)
ampp=2*sqrt(10/(3*pi-2))*sqrt(T-pi/2)

% --------------------------------------------------------------------------

function s = ddex1hist(t)
% Constant history function for DDEX1.
s = 2*ones(1);

% --------------------------------------------------------------------------

function dydt = ddex1de(t,y,Z)
% Differential equations function for DDEX1.
ylag1 = Z(:,1);
dydt = y(1)*(1-ylag1(1));
