function fig615

% clear all previous variables and plots

clear *
clf

% get(gcf)
%set(gcf,'Position', [805 516 578 232]);
set(gcf,'Position', [968 693 573 199]);
hold on

n=100;
ys=linspace(-3,3,n);
for i=1:n
	vs(i)=-ys(i)+ys(i)^3/3;
end;
plot(ys,vs,'--b','LineWidth',1.2)

% time interval
tmax=2;

y20=sqrt(3); y10=0; 
y0=[y10 y20];
% ep=0.01
%i1=98; ii1=i1+1;
%i2=335; ii2=i2+1;

% ep=0.001
i1=700; ii1=i1+1;
i2=2529; ii2=i2+1;

%  calculate solution using a MATLAB routine
[t,y] = ode45(@rhs,[0 tmax],y0);  
%[t,y] = ode23s(@rhs,[0 tmax],y0); 

size(y)

plot(y(:,2),y(:,1),'k','LineWidth',1)
arrowhead([y(i1,2) y(ii1,2)],[y(i1,1) y(ii1,1)],'r',[1.8 0.4]);
arrowhead([y(i2,2) y(ii2,2)],[y(i2,1) y(ii2,1)],'r',[1.8 0.4]);

axis([-3 3 -1.5 1.5]);
% commands to label each axes
xlabel('y-axis','FontSize',14,'FontWeight','bold')
ylabel('v-axis','FontSize',14,'FontWeight','bold')
grid on
% command to put legend into plot
%legend(' y_1',' y_2',4);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off

%  define f(t,y)
function dy=rhs(t,y)
dy=zeros(2,1);
ep=0.001;
dy(1) = -y(2);
dy(2) = (y(1)+y(2)-y(2)^3/3)/ep;













