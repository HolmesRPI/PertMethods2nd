function fig69

% clear all previous variables and plots
clear *
clf

% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

%  ep  fp1 (mu=40 cps)  fp2 (mu=30 cps)
ep1 = [0.10800,	0.11600,  0.12700,  0.14000,  0.14800,  0.15300];
ep2 = [	0.14500,  0.15125,  0.16500,  0.17300,  0.19125];fp1 = [1.6000,  1.7500,  2.0400,  2.3750,  2.5900,  2.6450];fp2 = [1.6000,  1.7600,  2.0000,  2.2000,  2.5500];

hold on
plot(ep1,fp1,'o','MarkerSize',7,'LineWidth',1)
plot(ep2,fp2,'s','MarkerSize',7,'LineWidth',1)

%axis([-1.5 2 -2 1]);
% commands to label each axes
xlabel('\epsilon-axis','FontSize',14,'FontWeight','bold')
ylabel('\omega-axis','FontSize',14,'FontWeight','bold')
grid on
% command to put legend into plot
loc='NorthWest';
legend(' \Omega = 40 cps',' \Omega = 30 cps','Location',loc);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off












