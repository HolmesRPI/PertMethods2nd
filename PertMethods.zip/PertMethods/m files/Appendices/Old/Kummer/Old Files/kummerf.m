function kummer

%  plot airy functions

% clear all previous variables and plots
clear *
clf

n=200;
x=linspace(-10,10,n);

% get(gcf)
set(gcf,'Position', [1203 762 515 280]);


for ix=1:n
	a(ix)=KummerComplex(-0.5,0.5,x(ix))
	b(ix)=KummerComplex(0.5,0.5,x(ix));
end;

hold on
box on
grid on
plot(x,a,'-','Linewidth',1)
plot(x,b,'--r','Linewidth',1)

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Airy Functions','FontSize',14,'FontWeight','bold')

%axis([-10 4 -1 4])
%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.5]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
legend(' a=-0.5',' a=0.5',2);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


