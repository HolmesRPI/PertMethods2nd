function kummer

clear *
clf

% x	a=1/2	a=-1/2	a=1/4	a=-1/4
load k_data.txt

x=k_data(:,1);
a1=k_data(:,2);
a2=k_data(:,3);

% get(gcf)
set(gcf,'Position', [1203 762 515 280]);

hold on
box on
grid on
plot(x,a1,'-','Linewidth',1)
plot(x,a2,'--r','Linewidth',1)

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('M(a,1/2,x)','FontSize',14,'FontWeight','bold')

axis([-40 10 -25 25])
%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.5]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
legend(' a=1/2',' a=-1/2',3);
set(findobj(gcf,'tag','legend'),'FontSize',14); 
