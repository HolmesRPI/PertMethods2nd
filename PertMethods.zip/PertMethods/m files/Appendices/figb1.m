function figb1

nx=200;
x=linspace(-10,4,nx);

% get(gcf)
set(gcf,'Position', [759 366 616 276]);


ep=0.1;
for ix=1:nx
	ai(ix)=airy(x(ix));
	bi(ix)=airy(2,x(ix));
end;

hold on
box on
grid on

plot(x,ai,'-r','Linewidth',1.2)
plot(x,bi,'--','Linewidth',1.2)

axis([-10 4 -1 4])
loc='NorthWest';
%loc='SouthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Airy Functions','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Ai(x)',' Bi(x)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 



