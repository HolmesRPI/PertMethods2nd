function bvp2

%  solve IVP using MATLAB routines
%         y'' = f(x,y,y')  with   y1(0) = a   y2(1)=b

% clear all previous variables and plots
clear *
clf

nx=20;

%  bcs
a=2;
b=-2;
solinit = bvpinit(linspace(0,1,nx),[a b]);


%  calculate solution using a MATLAB routine
options=bvpset('RelTol',1e-6);
sol =  bvp4c(@rhs,@bcs,solinit,options);
xx = sol.x;
yy = sol.y;
%[t,y] = ode23s(@rhs,[0 tmax],y0); 

%
%  2-D plot:  plot solutions as function of t
%
hold on
plot(xx,yy(1,:),'r')
%plot(t,y(:,3),'--b')

% commands to label each axes
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('y-axis','FontSize',14,'FontWeight','bold')

% command to put legend into plot
%legend(' y_1',' y_2',1);

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off

%  define f(x,y,y')
function dy=rhs(x,y)
dy=zeros(2,1);
ep=0.01; 
dy(1)=y(2);
dy(2)= -( y(1)*(1-y(1))*y(2) - x*y(1) )/ep;

function res = bcs(ya,yb)
a=2;
b=-2;
res = [  ya(1) - a
         yb(1) - b  ];











