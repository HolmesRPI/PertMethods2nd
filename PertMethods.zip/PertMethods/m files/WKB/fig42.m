function fig42

clf

% get(gcf)
%set(gcf,'Position', [802 575 573 199]);
set(gcf,'Position', [1896 1238 573 199]);

% n	Relative Error
load fig42data.txt

x=fig42data(:,1);
p=fig42data(:,2);

semilogy(x,p,'o','Linewidth',1)
hold on
box on
%grid on
%grid minor

set(gca,'XGrid','on')
set(gca,'YGrid','on','YMinorGrid','off')

axis([0 20 1e-5 1e-1])
%loc='NorthWest';
loc='SouthEast';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('Relative Error','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
set(gca,'ytick',[1e-5 1e-4 1e-3 1e-2 1e-1]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'-0.008';'-0.003';'0.002'})

set(gca,'FontSize',14);
hold off



