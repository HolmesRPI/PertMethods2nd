function fig415

clf

% n	yn
load fig415data.txt

x=fig415data(:,1);
y=fig415data(:,2);

% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

plot(x,y,'-','Linewidth',1)
hold on
box on
grid on

axis([-100 100 -8 8])
%loc='NorthWest';
loc='SouthEast';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('y_n','FontSize',14,'FontWeight','bold')


set(gca,'ytick',[-8 -4 0 4 8]);
set(gca,'FontSize',14);
hold off



