function fig417

clf

% get(gcf)
set(gcf,'Position', [1917 1035 560 420]);

% n	yn (numerical)
load fig417num.txt
xn=fig417num(:,1);
yn=fig417num(:,2);


% n	yL
load fig417yl.txt
xl=fig417yl(:,1);
yl=fig417yl(:,2);

% n	yR
load fig417yr.txt
xr=fig417yr(:,1);
yr=fig417yr(:,2);

subplot(2,1,1)
plot(xn,yn,'--r','Linewidth',1.3)
hold on
box on
grid on
plot(xl,yl,'-','Linewidth',1.3)
plot(xr,yr,'-','Linewidth',1.3)

%axis([-100 100 -8 8])
%loc='NorthWest';
loc='SouthEast';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('y_n','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[-8 -4 0 4 8]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'-0.008';'-0.003';'0.002'})

set(gca,'FontSize',14);
legend(' Numerical',' WKB','Location',[0.705456349206346 0.650950867635187 0.194444444444444 0.0841101694915254]);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

subplot(2,1,2)
hold on
box on
grid on

plot(xn,yn,'*r','Linewidth',1,'MarkerSize',7)
plot(xl,yl,'o','Linewidth',1.1)
plot(xr,yr,'o','Linewidth',1.1)
axis([40 60 0 10])

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('y_n','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
legend(' Numerical',' WKB','Location','EastOutside');
set(findobj(gcf,'tag','legend'),'FontSize',14); 
hold off





