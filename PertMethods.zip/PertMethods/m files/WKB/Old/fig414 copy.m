function fig414

clf

% n	yn (numerical)
load fig414num.txt
xn=fig414num(:,1);
yn=fig414num(:,2);


% n	yL
load fig414yl.txt
xl=fig414yl(:,1);
yl=fig414yl(:,2);

% n	yR
load fig414yr.txt
xr=fig414yr(:,1);
yr=fig414yr(:,2);


% get(gcf)
%set(gcf,'Position', [802 575 573 199]);
set(gcf,'Position', [1896 1238 573 199]);

plot(xn,yn,'--')
hold on
box on
grid on
plot(xl,yl,'-','Linewidth',1)
plot(xr,yr,'-','Linewidth',1)

%axis([-100 100 -8 8])
%loc='NorthWest';
loc='SouthEast';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('y_n','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[-8 -4 0 4 8]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'-0.008';'-0.003';'0.002'})

set(gca,'FontSize',14);
legend(' Numerical',' WKB','Location',loc);
%set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off



