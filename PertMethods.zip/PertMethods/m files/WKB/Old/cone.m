function cone

%  plots cone

clear *
clf

pa=[2;3;4];
pb=[1;1;1];
p=pa-pb;
theta=acos(p(3)/norm(p));
phi=acos(p(2)/sqrt(p(1)^2+p(2)^2));
R1=[1 0 0; 0 cos(theta) sin(theta); 0 -sin(theta) cos(theta)];
R2=[cos(phi) sin(phi) 0; -sin(phi) cos(phi) 0; 0 0 1];

hold on

% set parameters
nr=20;
nt=nr;

h=1;
r=1;

s=linspace(0,r,nr);
t=linspace(0,2*pi,nt);

for ir=1:nr
	for it=1:nt
		xq=s(ir)*cos(t(it));
		yq=s(ir)*sin(t(it));
		zq=h*(1-s(ir)/r);
		zq0=0;

		v=[xq;yq;zq];
		v0=[xq;yq;zq0];

		vv=R2*R1*v;
		vv0=R2*R1*v0;

		x(ir,it)=vv(1);
		y(ir,it)=vv(2);
		z(ir,it)=vv(3);

		x0(ir,it)=vv0(1);
		y0(ir,it)=vv0(2);
		z0(ir,it)=vv0(3);

	end;
end;

% get(gcf)
%set(gcf,'Position', [1889 957 560 420]);

%grid on
%box on


surf(x,y,z,'FaceColor',[0 0 0],'LineStyle','none')

surf(x0,y0,z0,'FaceColor',[0 0 0.65],'LineStyle','none')



%surfc(x,y,U')
%view(-160, 16);
%colormap gray
%axis off

% get(gca)
%set(gca,'ztick',[1 2 3]);
%set(gca,'ZTickLabel',{'-2';'-1';'0'})

%set(gca,'xtick',[-1 0 1]);
%set(gca,'ytick',[-1 0 1]);

%axis([-1 1 -1 1 -3 0])
%axes('position',[.13  .43  .8  .53])



