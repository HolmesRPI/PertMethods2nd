function fig45a

clf

% get(gcf)
set(gcf,'Position', [1896 1238 573 199]);

nx=100;

a=1; b= 1; ep=1/25;
t0 = sqrt(3)-log(2+sqrt(3))/2;
a0 = cos(t0/ep - pi/4);a1 = cos(t0/ep + pi/4);
aR = (a*3^(1/4) - b*a1*exp(-pi/(4*ep))) / (2*a0-a1*exp(-pi/(2*ep)));bR = exp(-pi/(4*ep))*(b - aR*exp(-pi/(4*ep)));
A = 2^(5/6)*sqrt(pi)*aR;B = bR*sqrt(pi)/2^(1/6);

xM=linspace(-0.2,0.2,nx);
for ix=1:nx	yM(ix) = (A*airy(2^(1/3)*xM(ix)/ep^(2/3)) + B*airy(2,2^(1/3)*xM(ix)/ep^(2/3)))/ep^(1/6);
end;

xL=linspace(-1,0.001,nx);
for ix=1:nx
	t = ( 1 - xL(ix) )*sqrt( xL(ix)^2 - 2*xL(ix) ) /2 - log( 1-xL(ix) + sqrt( xL(ix)^2 - 2*xL(ix) ) )/2;
	q = xL(ix)*(2-xL(ix));
	yL(ix) = (2*aR*cos(t/ep - pi/4) + bR*cos(t/ep + pi/4))/abs(q)^(1/4);
end;

xR=linspace(0.001,1,nx);
for ix=1:nx	k = (xR(ix)-1)*sqrt(2*xR(ix)-xR(ix)^2)/2 + asin(xR(ix)-1)/2 + pi/4;
	q = xR(ix)*(2-xR(ix));	yR(ix) = (aR*exp(-k/ep) + bR*exp(k/ep))/q^(1/4);
end;

hold on
box on
grid on

plot(xL,yL,'--b','Linewidth',1.3)

plot(xR,yR,'-.k','Linewidth',1.3)

plot(xM,yM,'-r','Linewidth',1.3)

axis([-1 1 -3 6])
%loc='NorthWest';
loc='NorthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' y_L',' y_R',' Y','Location',[0.72788107277636 0.62291542458053 0.114672364672365 0.146186440677966]);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

