function fig41

clf

% get(gcf)
%set(gcf,'Position', [802 575 573 199]);
set(gcf,'Position', [1896 1238 573 199]);

nx=1000;
x=linspace(0,1,nx);
a=1; b=0;
ep=0.1;
d=besselj(0,exp(1)/ep)*bessely(0,1/ep)-bessely(0,exp(1)/ep)*besselj(0,1/ep);
c0 = (b*bessely(0,1/ep)-a*bessely(0,exp(1)/ep))/d;
c1 = (a*besselj(0,exp(1)/ep)-b*besselj(0,1/ep))/d;
for ix=1:nx
	cc1=sin((exp(1)-1)/ep);
	cc2=sin((exp(x(ix))-exp(1))/ep);
	cc3=sin((exp(x(ix))-1)/ep);
	ya(ix)=exp(-0.5*x(ix))*(b*sqrt(exp(1))*cc2-a*cc2)/cc1;
	y(ix)=c0*besselj(0,exp(x(ix))/ep)+c1*bessely(0,exp(x(ix))/ep);
end;

hold on
box on
grid on

plot(x,y,'--','Linewidth',1)

plot(x,ya,'-r','Linewidth',1)

%axis([0 80 -2 2])
%loc='NorthWest';
loc='SouthWest';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact',' WKB','Location',[0.254379782521144 0.722078081083383 0.147435897435897 0.0841101694915254]);
set(findobj(gcf,'tag','legend'),'FontSize',14); 



