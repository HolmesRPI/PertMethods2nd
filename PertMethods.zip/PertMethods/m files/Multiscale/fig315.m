function fig315

clf

n=100;

% get(gcf)
set(gcf,'Position', [1528 750 585 272]);

ep=0.01;  w=0.5;
nn(1)=0;  nn(2)=1;
ye(1)=0;  ye(2)=1;
for i=3:n
	nn(i)=i-1;
	ye(i)=2*ye(i-1)-ye(i-2)-2*w^2*(ye(i-1)+ep*ye(i-1)^3);
end;

phi=acos(1-w^2);
%th0=pi/2
%A0=1/cos(phi+th0)
aa = (ye(1) - ye(2))^2 + 2*w^2*ye(1)*ye(2);
bb = w^2*(2-w^2);
A0 = sqrt(aa/bb);
th0 = acos(ye(1)/A0);
ang = ye(1)*(1-w^2)-ye(2)
if ( ang<0 && ye(1)>0 )
	th0 = th0 -pi
elseif ((ang<0)&&(ye(1)<0))
	th0 = th0 + pi/2;
end
alpha = 0.75*w*A0^2/sqrt(2-w^2);
th0 = th0 -pi

for i=1:n
	ya(i)=A0*cos((phi+ep*alpha)*(i-1)+th0);
end;

hold on
box on
grid on

plot(nn,ye,'ok','Linewidth',0.9)
plot(nn,ya,'-k','Linewidth',1)

axis([0 100 -2 3])
%loc='NorthWest';
loc='North';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact Solution',' Asymptotic Approximation','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 






