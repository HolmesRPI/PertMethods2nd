function fig313

clf

% get(gcf)
set(gcf,'Position', [1665 1089 638 257]);


epp=linspace(0,1,100);

for i=1:100
ep=epp(i);
s0(i) = -ep^2/2+7*ep^4/32-29*ep^6/144+68687*ep^8/294912-123707*ep^10/409600;
s025p(i) = 1/4-ep/2-ep^2/8+ep^3/32-ep^4/384-11*ep^5/4608+49*ep^6/36864-55*ep^7/294912-83*ep^8/552960+12121*ep^9/117964800-114299*ep^10/6370099200;
s025m(i) = 1/4+ep/2-ep^2/8-ep^3/32-ep^4/384+11*ep^5/4608+49*ep^6/36864+55*ep^7/294912-83*ep^8/552960-12121*ep^9/117964800-114299*ep^10/6370099200;
s1m(i) = 1-ep^2/12+5*ep^4/3456-289*ep^6/4976640+21391*ep^8/7166361600-2499767*ep^10/14447384985600;
s1p(i) = 1+5*ep^2/12-763*ep^4/3456+1002401*ep^6/4976640-1669068401*ep^8/7166361600+4363384401463*ep^10/14447384985600;
end


hold on
box on
grid on

plot(epp,s0,'-','Linewidth',1)
plot(epp,s025p,'-','Linewidth',1)
plot(epp,s025m,'-','Linewidth',1)
plot(epp,s1m,'-','Linewidth',1)
plot(epp,s1p,'-','Linewidth',1)

text(0.05,0.11,'S','FontSize',14,'FontWeight','bold')
text(0.05,0.51,'S','FontSize',14,'FontWeight','bold')
text(0.05,1.2,'S','FontSize',14,'FontWeight','bold')

text(0.63,-0.35,'N','FontSize',14,'FontWeight','bold')
text(0.9,0.2,'N','FontSize',14,'FontWeight','bold')
text(0.9,1.1,'N','FontSize',14,'FontWeight','bold')

axis([0 1 -0.5 1.5])
%loc='NorthWest';
loc='SouthEast';

xlabel('\epsilon','FontSize',18,'FontWeight','bold')
ylabel('\lambda','FontSize',18,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.5]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
%set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off


epp=linspace(0,1,100);

for i=1:100
ep=epp(i);
s0(i) = -ep^2/2+7*ep^4/32-29*ep^6/144+68687*ep^8/294912-123707*ep^10/409600;
s025p(i) = 1/4-ep/2-ep^2/8+ep^3/32-ep^4/384-11*ep^5/4608+49*ep^6/36864-55*ep^7/294912-83*ep^8/552960+12121*ep^9/117964800-114299*ep^10/6370099200;
s025m(i) = 1/4+ep/2-ep^2/8-ep^3/32-ep^4/384+11*ep^5/4608+49*ep^6/36864+55*ep^7/294912-83*ep^8/552960-12121*ep^9/117964800-114299*ep^10/6370099200;
s1m(i) = 1-ep^2/12+5*ep^4/3456-289*ep^6/4976640+21391*ep^8/7166361600-2499767*ep^10/14447384985600;
s1p(i) = 1+5*ep^2/12-763*ep^4/3456+1002401*ep^6/4976640-1669068401*ep^8/7166361600+4363384401463*ep^10/14447384985600;
end