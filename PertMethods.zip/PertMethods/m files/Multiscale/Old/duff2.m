function duff2
global ww
clf

tmax=800;

% get(gcf)
set(gcf,'Position', [756 523 579 261]);

ep=0.05; lambda=1; kap=6;
wmax=3*kap/(8*lambda^2)

nw=240;
cc=1/6;
w=linspace(2.7,3.3,nw);
for i=1:nw
	ww=w(i);
	y10=0; y20=0; 
	y0=[y10 y20];
	[t,y] = ode45(@rhs1,[0 tmax],y0);  
	%[t,y] = ode23s(@rhs1,[0 tmax],y0); 
	amp(i)=max(y(400:800,1));
%clf
%plot(t,y(:,1),'-r','Linewidth',1)
%axis([0 tmax -0.01 0.01]) 
%xlabel('t-axis','FontSize',14,'FontWeight','bold')
%ylabel('Solution','FontSize',14,'FontWeight','bold')
%pause

end

clf 
hold on
box on
grid on

plot(w,amp,'-r','Linewidth',1)

xlabel('w-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

%axis([0 tmax -1 1.5]) 
%text(-5,1.3,' \omega = - 20','FontSize',14)

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


%  define f(t,y)
function dy=rhs1(t,y)
global ww
ep=0.05; lambda=1; kap=6;
dy=zeros(2,1);
ff=ep*cos(ww*t);
dy(1) = y(2);
dy(2) = -y(1)-ep*lambda*y(2)-ep*kap*y(1)^3+ff;


