function duff3
global ww
clf

tmax=800;
ep=0.05; lambda=0; kap=6;

% get(gcf)
set(gcf,'Position', [756 523 579 261]);

ww=0;

y10=0; y20=0; 
y0=[y10 y20];
[t,y] = ode45(@rhs1,[0 tmax],y0);  
%[t,y] = ode23s(@rhs1,[0 tmax],y0); 

yy10=1/8; yy20=0; 
yy0=[yy10 yy20];
tmm = tmax*ep^3;
[t2,yy] = ode45(@rhs2,[0 tmm],yy0);  

[nt ntt]=size(t2)

t1=t2/ep^3;
for i=1:nt
	y0(i) = ep*( -cos( 3*t1(i) + ww*t2(i) )/8 + 2*y(i,1)*cos( t1(i) + y(i,2) )) ;
end

clf 
hold on
box on
grid on

plot(t,y(:,1),'-r','Linewidth',1)
plot(t1,y0,'-b','Linewidth',1)
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

%axis([0 tmax -1 1.5]) 
%text(-5,1.3,' \omega = - 20','FontSize',14)

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


%  define f(t,y)
function dy=rhs1(t,y)
global ww
ep=0.05; lambda=0; kap=6;
dy=zeros(2,1);
ff=ep*cos(ww*t);
dy(1) = y(2);
dy(2) = -y(1)-ep*lambda*y(2)-ep*kap*y(1)^3+ff;


%  define f(t,y)
function dy=rhs2(t,y)
global ww
ep=0.05; lambda=0; kap=6;
dy=zeros(2,1);
dy(1) = -3*kap*y(1)^2*sin(y(2)-ww*t)/32;
dy(2) = 0.5*kap*( 3/128 - 3*y(1)*cos(y(2)-ww*t)/16 + 3*y(1)^2) ;
















