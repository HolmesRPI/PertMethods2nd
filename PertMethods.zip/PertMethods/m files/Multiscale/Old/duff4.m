function duff4
global ww
clf

tmax=250;
ep=0.05; lambda=0; kap=4;

% get(gcf)
set(gcf,'Position', [756 523 579 261]);

ww=3/8;

y10=0; y20=0; 
y0=[y10 y20];
[t,y] = ode45(@rhs1,[0 tmax],y0);  

yy10=0.000000001; yy20=-pi/2; 
yy0=[yy10 yy20];
tmm = tmax*ep;
[t2,yy] = ode45(@rhs2,[0 tmm],yy0);  

[nt ntt]=size(t2)

t1=t2/ep;
clf 
hold on
box on
grid on

plot(t,y(:,1),'--r','Linewidth',1)
plot(t1,yy(:,1),'-b','Linewidth',1)
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
axis([0 tmax -1.5 1.5])

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


%  define f(t,y)
function dy=rhs1(t,y)
global ww
ep=0.05; lambda=0; kap=4;
dy=zeros(2,1);
ff=ep*cos((1+ep*ww)*t);
dy(1) = y(2);
dy(2) = -y(1)-ep*lambda*y(2)-ep*kap*y(1)^3+ff;


%  define f(t,y)
function dy=rhs2(t,y)
global ww
ep=0.05; lambda=0; kap=4;
dy=zeros(2,1);
dy(1) = - 0.5*lambda*y(1) - 0.5*sin(y(2)-ww*t);
dy(2) = 3*kap*y(1)^2/8 - 0.5*cos(y(2)-ww*t)/y(1) ;
















