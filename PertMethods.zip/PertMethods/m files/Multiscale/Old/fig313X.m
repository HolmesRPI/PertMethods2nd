function fig313

clf

load mathieudata.txt

ep=mathieudata(:,1);
c1=mathieudata(:,2);
c2=mathieudata(:,3);
c3=mathieudata(:,4);
c4=mathieudata(:,5);
c5=mathieudata(:,6);

% get(gcf)
set(gcf,'Position', [1665 1089 638 257]);

hold on
box on
grid on

plot(ep,c1,'-','Linewidth',1)
plot(ep,c2,'-','Linewidth',1)
plot(ep,c3,'-','Linewidth',1)
plot(ep,c4,'-','Linewidth',1)
plot(ep,c5,'-','Linewidth',1)

text(0.05,0.11,'S','FontSize',14,'FontWeight','bold')
text(0.05,0.51,'S','FontSize',14,'FontWeight','bold')
text(0.05,1.2,'S','FontSize',14,'FontWeight','bold')

text(0.63,-0.35,'N','FontSize',14,'FontWeight','bold')
text(0.9,0.2,'N','FontSize',14,'FontWeight','bold')
text(0.9,1.1,'N','FontSize',14,'FontWeight','bold')

%axis([0 tmax -0.601 0.6])
%loc='NorthWest';
loc='SouthEast';

xlabel('\epsilon','FontSize',18,'FontWeight','bold')
ylabel('\lambda','FontSize',18,'FontWeight','bold')

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
%set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off



