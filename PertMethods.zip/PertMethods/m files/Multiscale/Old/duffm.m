function duffm

global ep

clf

tmax=800;
ep=0.05; 

% get(gcf)
set(gcf,'Position', [1790 1003 579 261]);


y10=1; y20=1; 
y0=[y10 y20];

options = odeset('RelTol', 1e-12);

[t,y] = ode113(@rhs,[0 tmax],y0,options);  
%[t,y] = ode23s(@rhs,[0 tmax],y0); 


[nt ntt]=size(t);
a0 = y10^2 + y20^2;
k = 3*(7*y10^4 + 46*y10^2*y20^2 + 23*y20^4)/256;
w1 = 1 + 3*a0*ep/8;
w2 = w1 - k*ep^2;
w3 = w1 - 21*ep^2*a0^2/256
for i=1:nt
	y1(i) = y10*cos(w1*t(i)) + y20*sin(w1*t(i));
	y2(i) = y10*cos(w2*t(i)) + y20*sin(w2*t(i));
	y3(i) = y10*cos(w3*t(i)) + y20*sin(w3*t(i));
end

hold on
box on
grid on

plot(t,y(:,1),'-r','Linewidth',1)
plot(t,y1,'-g','Linewidth',1)
plot(t,y2,'-m','Linewidth',1)
plot(t,y3,'-b','Linewidth',1)
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

amp=sqrt(y10^2+y20^2);
ampp=1.1*amp;
axis([790 800 -ampp ampp]) 
%text(-5,1.3,' \omega = - 20','FontSize',14)

set(gca,'FontSize',14);
legend(' Num',' 2-term',' 3-term',' periodic');
set(findobj(gcf,'tag','legend'),'FontSize',14); 


%  define f(t,y)
function dy=rhs(t,y)
global ep
dy=zeros(2,1);
dy(1) = y(2);
dy(2) = - y(1)- ep*y(1)^3;
















