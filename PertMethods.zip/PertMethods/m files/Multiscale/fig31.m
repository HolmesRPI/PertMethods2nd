function fig31

nt=200;
t=linspace(0,80,nt);

% get(gcf)
set(gcf,'Position', [1665 1089 638 257]);

ep=0.1;
for it=1:nt
	ya(it)=sin(t(it))-0.5*ep*t(it)*sin(t(it));
	ye(it)=exp(-ep*t(it))*sin(t(it)*sqrt(1-0.25*ep^2))/sqrt(1-0.25*ep^2);
end;

hold on
box on
grid on

plot(t,ye,'-r','Linewidth',1.2)
plot(t,ya,'--','Linewidth',1.2)

axis([0 80 -2 2])
%loc='NorthWest';
loc='SouthWest';

xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

