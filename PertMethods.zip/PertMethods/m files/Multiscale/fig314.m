function fig314

clf

tmax=250;

% get(gcf)
set(gcf,'Position', [831 626 499 158]);

% numerical solution ep=0.01
%  x-axis   g(x)  u (t=5)   u (t=10)
load fisher1.txt
x1=fisher1(:,1);
u1=fisher1(:,2);
u1x=fisher1(:,3);
u1y=fisher1(:,4);

ep=0.01;
nx=200;
lambda=1;
x=linspace(-10,20,nx);
t1=5;
t2=10;
for ix=1:nx
	arg1 = t1 - lambda*x(ix) + lambda^2*ep*t1;  
	arg2 = t2 - lambda*x(ix) + lambda^2*ep*t2; 
	a1(ix) = 1/(1+exp(-arg1));
	a2(ix) = 1/(1+exp(-arg2));
end;

hold on
box on
grid on

say=['\epsilon = 0.01'];
text(-8,0.2,say,'FontSize',14,'FontWeight','bold')

plot(x1,u1,'-r','Linewidth',1)
plot(x1,u1x,'-r','Linewidth',1)
plot(x1,u1y,'-r','Linewidth',1)

plot(x,a1,'--','Linewidth',1)
plot(x,a2,'--','Linewidth',1)

text(-4.5,0.84,'t = 0','FontSize',14,'FontWeight','bold')
text(1.7,0.64,'t = 5','FontSize',14,'FontWeight','bold')
text(6.9,0.44,'t = 10','FontSize',14,'FontWeight','bold')

loc='SouthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 
hold off

figure

% numerical solution ep=0.1
%  x-axis   g(x)  u (t=5)   u (t=10)
load fisher2.txt
x2=fisher2(:,1);
u2=fisher2(:,2);
u2x=fisher2(:,3);
u2y=fisher2(:,4);

ep=0.1;
for ix=1:nx
	arg1 = t1 - lambda*x(ix) + lambda^2*ep*t1;  
	arg2 = t2 - lambda*x(ix) + lambda^2*ep*t2; 
	a1(ix) = 1/(1+exp(-arg1));
	a2(ix) = 1/(1+exp(-arg2));
end;

% get(gcf)
set(gcf,'Position', [312 504  499 158]);

hold on
box on
grid on

say=['\epsilon = 0.1'];
text(-8,0.2,say,'FontSize',14,'FontWeight','bold')

plot(x2,u2,'-r','Linewidth',1)
plot(x2,u2x,'-r','Linewidth',1)
plot(x2,u2y,'-r','Linewidth',1)

plot(x,a1,'--','Linewidth',1)
plot(x,a2,'--','Linewidth',1)

text(-4.5,0.84,'t = 0','FontSize',14,'FontWeight','bold')
text(1.7,0.64,'t = 5','FontSize',14,'FontWeight','bold')
text(6.9,0.44,'t = 10','FontSize',14,'FontWeight','bold')

%axis([0 tmax -0.601 0.6])
%loc='NorthWest';
loc='SouthEast';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
%legend(' Exact Solution',' y_0(t)+\epsilon y_1(t)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

