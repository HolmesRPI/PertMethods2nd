function fig32

nt=200;
t=linspace(0,80,nt);

% get(gcf)
%set(gcf,'Position', [831 504 515 280]);
set(gcf,'Position', [1665 1089 638 257]);

ep=0.1;
ee=sqrt(1-0.25*ep*ep);
for it=1:nt
	ya(it)=sin(t(it))*exp( -0.5*ep*t(it) );
	ye(it)=exp(-0.5*ep*t(it))*sin(t(it)*ee)/ee;
end;

hold on
box on
grid on

plot(t,ye,'-r','Linewidth',1.2)
plot(t,ya,'--','Linewidth',1.2)

axis([0 80 -1 1])
%loc='NorthWest';
loc='SouthEast';

xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact Solution',' y_0(t_1,t_2)','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

