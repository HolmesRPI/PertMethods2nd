function integrate


%  simpson's method

ep=0.001
N=10000000;
xM=pi/3;
x=linspace(0,xM,N+1);
h=x(2)-x(1);

s=integrand(x(1),ep);
for j=2:2:N
	f2=integrand(x(j+1),ep);
	s=s+4*integrand(x(j),ep)+2*f2;
end;
s=h*(s-f2)/3;
app=-2*log(ep)+log(2/sqrt(3));

error = s-app

%app=0.5*pi/ep-1

function f = integrand(x,ep)
f = 1/(ep^2+ sin(x));

%function f = integrand(x,ep)
%f = 1/(ep^2+ x^2);