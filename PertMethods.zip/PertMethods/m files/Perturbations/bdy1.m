function bdy1

%  solve bdv


clear *
clf

nx=100;
% get(gcf)
set(gcf,'Position', [1041 771 548 229]);

ep=0.00001;
pow=linspace(-6,0,nx);
for ix=1:nx
    x(ix)=10^pow(ix);
	outer(ix)=exp(1-x(ix));  
	inner(ix)=exp(1)*(1-exp(-2*x(ix)/ep));
	composite(ix)=exp(1-x(ix))-exp(1-2*x(ix)/ep);
end;

semilogx(x,outer,'-b','LineWidth',1)
hold on

semilogx(x,inner,'--r','LineWidth',1)
box on
%axis([0.01 1 0.5 1.1])
%title('\epsilon = 0.01','FontSize',14,'FontWeight','bold')
legend(' Outer',' Inner',4);
xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off


