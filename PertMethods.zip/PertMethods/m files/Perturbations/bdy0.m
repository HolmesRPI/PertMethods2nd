function bdy

%  solve bvp


clear *
clf

nx=300;
% get(gcf)
set(gcf,'Position', [1041 771 548 229]);

ep=1;
r1=(-1+sqrt(1-2*ep))/ep; 
r2=(-1-sqrt(1-2*ep))/ep;
A=1/(exp(r1)-exp(r2));
B=-A;
x=linspace(0,1,nx);
for ix=1:nx
	ye0(ix)=A*exp(r1*x(ix))+B*exp(r2*x(ix));
end;

ep=0.1;
r1=(-1+sqrt(1-2*ep))/ep; 
r2=(-1-sqrt(1-2*ep))/ep;
A=1/(exp(r1)-exp(r2));
B=-A;
for ix=1:nx
	ye1(ix)=A*exp(r1*x(ix))+B*exp(r2*x(ix));
end;

ep=0.01;
r1=(-1+sqrt(1-2*ep))/ep; 
r2=(-1-sqrt(1-2*ep))/ep;
A=1/(exp(r1)-exp(r2));
B=-A;
for ix=1:nx
	ye2(ix)=A*exp(r1*x(ix))+B*exp(r2*x(ix));
end;

hold on

plot(x,ye0,'-.r','LineWidth',1)
plot(x,ye1,'--b','LineWidth',1)
plot(x,ye2,'-k','LineWidth',1)
box on
%axis([0.01 1 0.5 1.1])
%title('\epsilon = 0.01','FontSize',14,'FontWeight','bold')
legend(' \epsilon = 1',' \epsilon = 0.1',' \epsilon = 0.01',1);
xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off
