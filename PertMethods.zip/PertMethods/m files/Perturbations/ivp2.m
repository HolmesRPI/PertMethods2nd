function ivp2

%  solve projectile problem

clear *
clf

ddy=0.85;

y0=1;
ep=0.01;

tmax=2;

[t,y] = ode45(@rhs2,[0 tmax],[0 1]);

% get(gcf)
set(gcf,'Position', [1209 840 577 197]);

tt=linspace(0,tmax,100);
for it=1:100
	asy0(it)=tt(it)*(1-0.5*tt(it));
	asy1(it)=asy0(it)+ep*tt(it)^3*(4-tt(it))/12;
end;

hold on
box on
plot(t,y(:,1))
plot(tt,asy0,'--k','LineWidth',1)
plot(tt,asy1,'-.r','LineWidth',1)
axis([0 2.5 0 0.601])
legend(' Numerical',' 1 term',' 2 terms',1);
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
text(ddy,0.1,'\epsilon = 0.01','FontSize',16,'FontWeight','bold');
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off

figure
ep=0.1;
tmax=2.2;

[tz,yy] = ode45(@rhs,[0 tmax],[0 1]);

% get(gcf)
set(gcf,'Position', [1201 530 577 197]);

tt=linspace(0,tmax,100);
for it=1:100
	asy00(it)=tt(it)*(1-0.5*tt(it));
	asy11(it)=asy00(it)+ep*tt(it)^3*(4-tt(it))/12;
end;

hold on
box on
plot(tz,yy(:,1))
plot(tt,asy00,'--k','LineWidth',1)
plot(tt,asy11,'-.r','LineWidth',1)
axis([0 2.5 0 0.601])
legend(' Numerical',' 1 term',' 2 terms',1);
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
text(ddy,0.1,'\epsilon = 0.1','FontSize',16,'FontWeight','bold');
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off

function dy=rhs(t,y)
dy=zeros(2,1);
ep=0.1;
dy(1)=y(2);
dy(2)=-1/(1+ep*y(1))^2;

function dy=rhs2(t,y)
dy=zeros(2,1);
ep=0.01;
dy(1)=y(2);
dy(2)=-1/(1+ep*y(1))^2;





