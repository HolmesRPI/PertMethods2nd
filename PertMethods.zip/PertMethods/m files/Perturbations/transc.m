function transc

%  solve transcendental equation using MATLAB routines


clear *
clf


% get(gcf)
set(gcf,'Position', [1041 771 548 229]);



pow=linspace(-2,0,100);
for ip=1:100
    ep(ip)=10^pow(ip);
	x(ip)=fzero(@(x) rhs(x,ep(ip)),1);
	asy(ip)=1-ep(ip)^2*exp(-1)/3;
end;

semilogx(ep,x,'k','LineWidth',1)
hold on

semilogx(ep,asy,'--r','LineWidth',1.2)
box on
axis([0.01 1 0.5 1.1])
%title('\epsilon = 0.01','FontSize',14,'FontWeight','bold')
legend(' Numerical',' Asymptotic Approximation',3);
xlabel('\epsilon-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off

function f=rhs(x,ep)
f=x^3+ep^2*exp(x)-1-ep^5;