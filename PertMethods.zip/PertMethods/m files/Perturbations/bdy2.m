function bdy2

%  solve bdv


clear *
clf

nx=200;
% get(gcf)
set(gcf,'Position', [1281 735 577 197]);

ep=0.1;
r1=(-1+sqrt(1-2*ep))/ep; 
r2=(-1-sqrt(1-2*ep))/ep;
A=1/(exp(r1)-exp(r2));
B=-A;

x=linspace(0,1,nx);
for ix=1:nx
	ye(ix)=A*exp(r1*x(ix))+B*exp(r2*x(ix));
	composite(ix)=exp(1-x(ix))-exp(1-2*x(ix)/ep);
end;

plot(x,ye,'k','LineWidth',1)
hold on

plot(x,composite,'--r','LineWidth',1)
box on
%axis([0.01 1 0.5 1.1])
%title('\epsilon = 0.01','FontSize',14,'FontWeight','bold')
legend(' Exact',' Composite',1);
xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
dy=1+0.9*1;
text(0.8,0.4,'\epsilon = 0.1','FontSize',16,'FontWeight','bold');
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off

