function ivp22

%  solve projectile problem

clear *
clf

ddy=0.85;

y0=1;
ep=0.02;

tmax=3;

[t,y] = ode45(@rhs2,[0 tmax],[0 1]);

% get(gcf)
set(gcf,'Position', [1209 840 577 197]);

tt=linspace(0,tmax,100);
for it=1:100
	asy0(it)=tt(it)*(1-0.5*tt(it));
	asy1(it)=asy0(it)+ep*tt(it)^3*(4-tt(it))/12;
end;

hold on
box on
plot(t,y(:,1))
plot(tt,asy0,'--k','LineWidth',1)
plot(tt,asy1,'-.r','LineWidth',1)
axis([0 tmax 0 1])
%legend(' Numerical',' 1 term',' 2 terms',1);
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold');  
hold off

function dy=rhs2(t,y)
dy=zeros(2,1);
ep=0.02;
dy(1)=y(2);
dy(2)=-1/(1+ep*y(1))^2;





