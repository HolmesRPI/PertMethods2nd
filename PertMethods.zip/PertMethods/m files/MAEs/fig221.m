function fig221

clf

nx=1000;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [1925 1095 573 199]);

ep=0.0001;

%  y'' + p(x)y' + q(x)y= f(x)   for xL < x < xR
% set boundary conditions
	xL=0; yL=-2;
	xR=1; yR=2;

h=x(2)-x(1);
% calculate the coefficients of finite difference equation
a=zeros(1,nx-2); b=zeros(1,nx-2); c=zeros(1,nx-2);
	for i=1:nx-2
		a(i)=-2+h*h*q(x(i+1),ep);
		b(i)=1-0.5*h*p(x(i+1),ep);
		c(i)=1+0.5*h*p(x(i+1),ep);
		f(i)=h*h*rhs(x(i+1),ep);
	end;
f(1)=f(1)-yL*b(1);
f(nx-2)=f(nx-2)-yR*c(nx-2);
% solve the tri-diagonal matrix problem
y=tri(a,b,c,f);
y=[yL, y, yR];

plot(x,y,'-','Linewidth',1)
hold on

box on
grid on
axis([0 1.02 -2 2])
loc='SouthEast';
%loc='South';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);

function g=q(x,ep)
g=-x/ep;

function g=p(x,ep)
a=0.25;  b=0.75;
g=-(x-a)*(x-b)/ep;

function g=rhs(x,ep)
g=-x/ep;

% tridiagonal solver
function y = tri( a, b, c, f )
N = length(f);
v = zeros(1,N);   
y = v;
w = a(1);
y(1) = f(1)/w;
for i=2:N
    v(i-1) = c(i-1)/w;
    w = a(i) - b(i)*v(i-1);
    y(i) = ( f(i) - b(i)*y(i-1) )/w;
end
for j=N-1:-1:1
   y(j) = y(j) - v(j)*y(j+1);
end



