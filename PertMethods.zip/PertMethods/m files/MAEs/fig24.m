function fig24


clf

nx=200;
x=linspace(0.001,1,nx);

% get(gcf)
set(gcf,'Position', [654 548 573 199]);

ep=0.01;
rp=(-1+sqrt(1-2*ep))/ep;  rm=(-1-sqrt(1-2*ep))/ep;
alp=1/(exp(rp)-exp(rm));  bet=-alp;
for ix=1:nx
	y(ix) = alp*exp(rp*x(ix)) + bet*exp(rm*x(ix));  
	ya(ix) = exp(1-x(ix)) - exp(1-2*x(ix)/ep);
end;

plot(x,y,'--','Linewidth',1)
hold on
plot(x,ya,'-','Linewidth',1)

say=['\epsilon = ',num2str(ep)];
text(0.82,2.18,say,'FontSize',14,'FontWeight','bold')

box on
grid on
%axis([0 2 0 0.6])
loc='South';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'ytick',[0 1 2 3]);
set(gca,'FontSize',14);
legend(' Exact Solution',' Composite Expansion','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 
