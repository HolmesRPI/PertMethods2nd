function fig2

% r-axis  Exact
load exactdata.txt

exactdata

re=exactdata(:,1);
ue=exactdata(:,2);

plot(re,ue,'r')

