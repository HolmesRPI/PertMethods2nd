function burger

%  plot of solution of 
%  u_t + u u_x = ep*u_xx  for  x0 < x < x1  
%  u(x,0) = step(u_1,u_2) where u_1 > u_2

% set boundary conditions
ep=0.1;
u1=1;
u2=0;
x0=-10;
x1=10;

% parameters for plot
nx = 200;
nt = 20;
tmax=10;

x=linspace(x0,x1,nx); 
t=linspace(0,tmax,nt); 

u=zeros(nx,nt);
for i=1:nx
	u(i,1)=g(x(i),u1,u2);
end;

for it=2:nt
	v0=0.5*(u2+u1);
	w0=0.5*(u2-u1);
	for ix=1:nx
		q1 = 0.5*(x(ix)-u1*t(it))/sqrt(ep*t(it));
		q2 = 0.5*(x(ix)-u2*t(it))/sqrt(ep*t(it));
		q3 = (x(ix)-v0*t(it))*w0/ep;
		k = erfc(q1)*exp(q3)/erfc(-q2);
		u(ix,it)=(u2+k*u1)/(1+k);
	end;
end;

% get(gcf)
set(gcf,'Position', [753 616 560 530]);

hold on
%axes('position',[.13  .43  .8  .53])
surf(x,t,u')
%surfc(x,t,u')
%contour(x,t,u')

%view(38, 22);
colormap gray

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('t-axis','FontSize',14,'FontWeight','bold')
zlabel('Solution','FontSize',14,'FontWeight','bold')
% Set the fontsize to 12 for the plot '
set(gca,'FontSize',12); 

function q=g(x,u1,u2)
if x < 0
	q=u1;
else
	q=u2;
end;





