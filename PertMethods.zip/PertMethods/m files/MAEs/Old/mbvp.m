function bvp

%  solve BVP using MATLAB routines

%  y'' + p(x)y' + q(x)y = f(x)   for xL < x < xR
% set boundary conditions
	xL=0; yL=-2;
	xR=1; yR=3;

clear *
clf

% get(gcf)
set(gcf,'Position', [702 483 678 301]);

%  calculate solution using a MATLAB routine
sol0 = bvpinit(linspace(0,1,1000),@mat4init);
sol = bvp4c(@rhs,@bcs,sol0)

%  plot 
hold on
   xint = linspace(0,1);
    Sxint = deval(sol,xint);
plot(xint,Sxint(1,:))
box on
% commands to label each axes)
xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
%set(gca,'xtick',[0]);
%set(gca,'ytick',[0]);
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
hold off

%  define RHS of equations
function dy=rhs(x,y)
dy=zeros(2,1);
ep=0.1; a=0.5;  b=0.6;
dy(1) = y(2);
dy(2) = ( f(x,a,b,ep) - p(x,a,b,ep)*y(2) - q(x,a,b,ep)*y(1) )/ep;

%  define BCs
function res = bcs(ya,yb,lambda)
a0=-2; b0=2;
res = [  ya(1) - a0
         yb(2) - b0 ];

function yinit = mat4init(x)
a0=-2; b0=2;
yinit = [  a0+(b0-a0)*x
          b0-a0 ];


function g=q(x,a,b,ep)
g=0;

function g=p(x,a,b,ep)
g=4*(x-a)*(x-b)/ep;

function g=f(x,a,b,ep)
g=(x-a)*(x-b)/ep;










