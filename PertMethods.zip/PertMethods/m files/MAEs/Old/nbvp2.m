function nbvp2

% check exercises in section 2.2

% code to solve, and then plot, the solution of the nonlinear BVP
%        y'' = f(x, y, y')     for xL < x < xR  
% where 
%          y(xL) = yL ,  y(xR) = yR

% an explanation of how to use this code is given at the end of this file

% set boundary conditions
	xL=0; yL=2;
	xR=1; yR=2;

% parameters for calculation
nx = 10000;
error = 0.000001;

% start off with a linear solution
x=linspace(xL,xR,nx+2); 
for ix=1:nx+2
	y(ix) = yL + (yR-yL)*x(ix);
end;


%clf
% get(gcf)
%set(gcf,'Position', [1925 1095 573 199]);

dx=x(2)-x(1);
dxx = dx*dx;
err=1;

counter=0;
while err > error

	% calculate the coefficients of finite difference equation
	a=zeros(1,nx); c=zeros(1,nx); v=zeros(1,nx); u=zeros(1,nx);
	for j = 2:nx+1
		jj=j-1;
		z = (y(j+1) - y(j-1))/(2*dx);
		a(jj) = 2 + dxx*fy(x(j), y(j), z);
		c(jj) = -1 - 0.5*dx*fz(x(j), y(j), z);
		v(jj) = - 2*y(j) + y(j+1) + y(j-1) - dxx*f(x(j), y(j), z);
	end;

	% Newton iteration
	v(1) = v(1)/a(1);
	u(1) = - (2 + c(1))/a(1);
	for j = 2:nx
		xl = a(j) - c(j)*u(j-1);
		v(j) = (v(j) - c(j)*v(j-1))/xl;
		u(j) = - (2 + c(j))/xl;
	end;
	vv = v(nx);
	y(nx+1) = y(nx+1) + vv;
	err = abs(vv);
	for jj = nx:-1:2
		vv = v(jj-1) - u(jj-1)*vv;
		err = max(err, abs(vv));
		y(jj) = y(jj) + vv;
	end;
	counter=counter+1;
end;

newton_iterations=counter

% plot computed solution
plot(x,y)
hold on
grid on
box on
%axis([-0.02 1.02 -2 2])
xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
hold off

%  right hand side of differential equation
function g=f(x,y,z)
ep=0.001;
% g = (x-1+y-ep*(x+1)^2*z)/ep;   % a
% g = (1+z-y^2)/ep;  % b
% g = (-ep*z+y^2-1-x^2)/ep;  % c
% g = y*(z+1)/ep;  % d
% g = (-y*(1-y)*z+y)/ep;  % e
% g = (-ep*(3-x^2)*z+4*y+4*x)/ep^2;  % f
g = (y*(1+y)*z+3*y)/ep;  % g

%  fy(x,y,z) = diff(f,y)
function g=fy(x,y,z)
ep=0.001;
% g = 1/ep;   % a
% g = -2*y/ep;  % b
% g = 2*y/ep;  % c
% g = (z+1)/ep;  % d
% g = (-(1-2*y)*z+1)/ep;  % e
% g = 4/ep^2;  % f
g = ((1+2*y)*z+3)/ep;  % g

%  fz(x,y,z) = diff(f,z)
function g=fz(x,y,z)
ep=0.001;
% g = -(x+1)^2*z;   % a
% g = 1/ep;  % b
% g = -1;  % c
% g = y/ep;  % d
% g = -y*(1-y)/ep;  % e
% g = -(3-x^2)/ep;  % f
g = y*(1+y)/ep;  % g


























