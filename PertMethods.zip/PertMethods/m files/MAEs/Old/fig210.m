function fig210

clf

nx=2000;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [805 363 560 420]);

ep=0.01;
for ix=1:nx
	x2=x(ix)-0.5;
	y2(ix)=0.5*tanh(x2/ep)+(sech(x2/ep))^2;
	y1(ix)=(sech(x2/ep))^2;
end;

subplot(2,1,1)
hold on
box on
grid on

plot(x,y1,'-r','Linewidth',1)

axis([0 1 -0.1 1])

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 0.5]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';'x_M'})

subplot(2,1,2)
hold on
box on
grid on

plot(x,y2,'-','Linewidth',1)

axis([0 1 -0.6 1.1])

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')
set(gca,'FontSize',14);
