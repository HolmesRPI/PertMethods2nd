function fig228d

%  generate data for fig 228 

ep=0.05; 
b=0;  a=1;
alpha=1;  beta=1;

% set parameters
nr = 200;
pi2=2*pi;
ab2 = alpha^2+beta^2;

fid = fopen('exactdata.txt', 'w');

r=linspace(-1,1,nr);
phi=pi/4;
for ir=1:nr
	x=r(ir)*cos(pi/4);
	y=r(ir)*sin(pi/4);
	rr=(beta*x-alpha*y)/ab2;
	s=(alpha*x+beta*y)/ab2;
	ho=sqrt(1/ab2-rr^2);
	hb=-ho;
	mu=1+(rr/ho)^2;
	ss=(s-hb)/ep;
	ehs=exp(ho-s);
	ehb=exp(ho-hb);
	u(ir)=a+(b-a)*ehs+(b-a)*(1-ehb)*exp(-ab2*ss/mu);

fprintf(fid, '%12.6f %12.6f\n', r(ir), u(ir));

end;

% plot(r,u,'-','Linewidth',1)

fclose(fid);









