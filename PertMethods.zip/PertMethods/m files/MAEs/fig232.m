function fig232

clf

nx=200;
x=linspace(-10,30,nx);

% get(gcf)
%set(gcf,'Position', [1948 1118 573 199]);
set(gcf,'Position', [990 937 613 186]);


ep=1;

t=1;
for ix=1:nx
	s1 = erfc( 0.5*(x(ix)-t)/sqrt(ep*t) );
	s2 = erfc( -0.5*x(ix)/sqrt(ep*t) );
	k = s1*exp(- 0.5*(x(ix)-0.5*t)/ep )/s2;
	u1(ix) = k/(1+k);
	xb = (x(ix)-0.5*t)/ep;
	ua1(ix) = exp(-0.5*xb)/(1+exp(-0.5*xb));
end;

t=15;
for ix=1:nx
	s1 = erfc( 0.5*(x(ix)-t)/sqrt(ep*t) );
	s2 = erfc( -0.5*x(ix)/sqrt(ep*t) );
	k = s1*exp(- 0.5*(x(ix)-0.5*t)/ep )/s2;
	u2(ix) = k/(1+k);
	xb = (x(ix)-0.5*t)/ep;
	ua2(ix) = exp(-0.5*xb)/(1+exp(-0.5*xb));
end;

t=30;
for ix=1:nx
	s1 = erfc( 0.5*(x(ix)-t)/sqrt(ep*t) );
	s2 = erfc( -0.5*x(ix)/sqrt(ep*t) );
	k = s1*exp(- 0.5*(x(ix)-0.5*t)/ep )/s2;
	u3(ix) = k/(1+k);
	xb = (x(ix)-0.5*t)/ep;
	ua3(ix) = exp(-0.5*xb)/(1+exp(-0.5*xb));
end;

plot(x,u1,'--','Linewidth',1)
hold on
plot(x,ua1,'-','Linewidth',1)

plot(x,u2,'--','Linewidth',1)
plot(x,ua2,'-','Linewidth',1)

plot(x,u3,'--','Linewidth',1)
plot(x,ua3,'-','Linewidth',1)

%  ep=1
text(-5.5,0.7,'t = 1','FontSize',14,'FontWeight','bold')
text(2.05,0.6,'t = 15','FontSize',14,'FontWeight','bold')
text(10.4,0.5,'t = 30','FontSize',14,'FontWeight','bold')
say=['\epsilon = ',num2str(ep)];
text(26,0.88,say,'FontSize',14,'FontWeight','bold')

%  ep=0.1
%text(-3.3,0.7,'t = 1','FontSize',14,'FontWeight','bold')
%text(3.3,0.6,'t = 15','FontSize',14,'FontWeight','bold')
%text(10.8,0.5,'t = 30','FontSize',14,'FontWeight','bold')
%say=['\epsilon = ',num2str(ep)];
%text(24,0.88,say,'FontSize',14,'FontWeight','bold')

box on
grid on
axis([-10 30 -0.05 1.05])
%loc='NorthWest';
loc='East';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Exact',' Asymptotic','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


