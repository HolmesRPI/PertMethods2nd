function fig29

clf

nx=2000;
x=linspace(0,1,nx);

% get(gcf)
set(gcf,'Position', [1891 898 552 376]);

ep=0.001;

%  y'' + p(x)y' + q(x)y= f(x)   for xL < x < xR
% set boundary conditions
	xL=0; yL=1;
	xR=1; yR=3;

h=x(2)-x(1);
% calculate the coefficients of finite difference equation
a=zeros(1,nx-2); b=zeros(1,nx-2); c=zeros(1,nx-2);
	for i=1:nx-2
		a(i)=-2+h*h*q(x(i+1),ep);
		b(i)=1-0.5*h*p(x(i+1),ep);
		c(i)=1+0.5*h*p(x(i+1),ep);
		f(i)=h*h*rhs(x(i+1),ep);
	end;
f(1)=f(1)-yL*b(1);
f(nx-2)=f(nx-2)-yR*c(nx-2);
% solve the tri-diagonal matrix problem
y=tri(a,b,c,f);
y=[yL, y, yR];

% asy solution
nx=1000;
xx=linspace(0.0001,1,nx);
for ix=1:nx
	yx(ix) = exp(-xx(ix)/ep) + 2*exp(-0.5*ep/xx(ix)^2) + xx(ix);
end

subplot(2,1,1)
plot(x,y,'b','Linewidth',1)
hold on
%plot(xx,yx,'r','Linewidth',1)


box on
grid on
axis([-0.04 1 -0.25 3])
loc='NorthWest';
%loc='South';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);


subplot(2,1,2)
plot(x,y,'b','Linewidth',1)
hold on
%plot(xx,yx,'r','Linewidth',1)
axis([-0.001 0.03 -0.1 1])

box on
grid on

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
%legend(' Numerical Solution',' Composite Expansion','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 






function g=q(x,ep)
g=-1/ep^2;

function g=p(x,ep)
g=x^3/ep^3;

function g=rhs(x,ep)
g=x^3/ep^3;

% tridiagonal solver
function y = tri( a, b, c, f )
N = length(f);
v = zeros(1,N);   
y = v;
w = a(1);
y(1) = f(1)/w;
for i=2:N
    v(i-1) = c(i-1)/w;
    w = a(i) - b(i)*v(i-1);
    y(i) = ( f(i) - b(i)*y(i-1) )/w;
end
for j=N-1:-1:1
   y(j) = y(j) - v(j)*y(j+1);
end























