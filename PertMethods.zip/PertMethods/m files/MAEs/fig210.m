function fig210

clf

% x-axis  phi-axis
load fig210data.txt

x=fig210data(:,1);
p=fig210data(:,2);

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

hold on
box on
grid on

plot(x,p,'-','Linewidth',1)

axis([-0.04 1.04 -0.008 0.002])

xlabel('x-axis','FontSize',18,'FontWeight','bold')
ylabel('\phi -axis','FontSize',18,'FontWeight','bold')

set(gca,'ytick',[-0.008 -0.003 0.002]);
set(gca,'YTickLabel',{'-0.008';'-0.003';'0.002'})

set(gca,'FontSize',14);

hold off



