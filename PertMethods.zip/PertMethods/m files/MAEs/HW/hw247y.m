function hw247y

%  calculates exact solution of HW 2.4.7

% set boundary conditions
	xL=0; yL=-2;
	xR=1; yR=3;

a0=0.249;
a0=0.251;
b0=0.75;

nx=2000;
ep=1/10^2.544;

%clf
% get(gcf)
%set(gcf,'Position', [1868 1186 573 199]);
%set(gcf,'Position', [858 595 514 149]);

x=linspace(0,1,nx);
h=x(2)-x(1);
% calculate the integrals
sum(1)=0;
for i=2:nx
	x1=x(i-1);  x2=x1+0.5*h;  x3=x(i);
	f1=f(x1,a0,b0,ep); f2=f(x2,a0,b0,ep); f3=f(x3,a0,b0,ep);
	sum(i)=sum(i-1) + 0.5*h*(f1+4*f2+f3)/3;
end;
for i=1:nx
	y(i)=-2+x(i)/4+19*sum(i)/(4*sum(nx));
end;

plot(x,y,'-','Linewidth',1)
hold on

%say=['\epsilon = ',num2str(ep)];
say=['a = ',num2str(a0)];
text(0.03,-1.2,say,'FontSize',14,'FontWeight','bold')
%text(0.82,1.2,say,'FontSize',14,'FontWeight','bold')

box on
grid on
axis([-0.04 1.0 -2.2 3.1])
loc='SouthEast';
%loc='South';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[0 1 2 3]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'0';' ';' ';' '})

set(gca,'FontSize',14);
%legend(' Numerical',' Composite',' Outer','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


function g=f(x,a,b,ep)
p=2*x^3-3*(a+b)*x^2+6*a*b*x;
g=exp(-2*p/(3*ep));

