function hw237

%  solve IVP using MATLAB routines
%         y' = f(t,y)  with   y(0) = y0        
%  where y = (y1, y2, y3 , ..., yn) is an n-vector


% clear all previous variables and plots
clear *
%clf

% get(gcf)
set(gcf,'Position', [1677 1122 665 250]);
hold on

tmax=1.2;
y0=1;

%  calculate solution using a MATLAB routine
%[t,y] = ode45(@rhs,[0 tmax],y0);  
[t,y] = ode23s(@rhs,[0 tmax],y0); 

plot(t,y,'g')

qq=size(t)
t(qq(1))
y(qq(1))

%axis([0 500 -0.2 4]);
% commands to label each axes
xlabel('t-axis','FontSize',14,'FontWeight','bold')
ylabel('y - axis','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 100 200 300 400 500]);

grid on
% command to put legend into plot
%legend(' a = 1',' a = -1','Location','East');

% have MATLAB use certain plot options (all are optional)
box on
% Set the fontsize to 14 for the plot
set(gca,'FontSize',14); 
% Set legend font to 14/bold                            		
set(findobj(gcf,'tag','legend'),'FontSize',14,'FontWeight','bold'); 

hold off


%  define f(t,y)
function dy=rhs(t,y)
ep=0.02;
Ti=2; 
n=6;
dy = ep*(Ti - y)^n * exp( (y-1)/(ep*y) ); 



