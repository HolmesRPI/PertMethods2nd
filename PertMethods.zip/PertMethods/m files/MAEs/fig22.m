function fig22

%  do not use "expand to axes"
clf

nx=200;
x=linspace(0.001,1,nx);

% get(gcf)
set(gcf,'Position', [831 555 548 229]);

fact=2.4/exp(1);
ep=0.00001;
pow=linspace(-6,0,nx);
for ix=1:nx
    x(ix)=10^pow(ix);
	outer(ix)=fact*exp(1-x(ix));  
	inner(ix)=exp(1)*(1-exp(-2*x(ix)/ep));
	composite(ix)=exp(1-x(ix))-exp(1-2*x(ix)/ep);
end;

semilogx(x,outer,'--','Linewidth',1)
hold on
semilogx(x,inner,'-','Linewidth',1)


box on
grid on
%axis([0 2 0 0.6])
%loc='NorthWest';
loc='South';

xlabel('x-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'YTickLabel',{'0';' ';' ';' '})
set(gca,'FontSize',14);
legend(' Outer Approximation',' Inner Approximation','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 

%text(-0.1,1.2,'S','FontSize',14,'FontWeight','bold')

annotation(gcf,'textbox',[0.9121 0.8211 0.05685 0.1],'String',{'A'},'FitBoxToText','off','EdgeColor','white','FontSize',14);
annotation(gcf,'textbox',[0.08426 0.7606 0.08915 0.09],'String',{'e'},'FitBoxToText','off','EdgeColor','white','FontSize',14);


