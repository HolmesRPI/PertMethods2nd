function fig234

clf

N=20;
y0=1;
yN=-1;

% get(gcf)
set(gcf,'Position', [1868 1153 573 232]);

ep=0.001;

for i=1:N
	x(i)=i;
	alpha(i)=-(1+i/N);
	beta(i)=1.5-i/N;
end;

lam(1)=-1/alpha(N);
k(1)=-beta(1)/alpha(1);
for i=2:N
	k(i)=k(i-1)*(-beta(i)/alpha(i));
	lam(i)=-lam(i-1)/alpha(N-i+1);
end;

for i=1:N-1
	ya(i)=k(i)*y0 + ep^(N-i)*lam(N-i)*(yN-k(N)*y0);
end;
ya=[y0, ya, yN];
x=[0, x ];

% numerical sol
a=zeros(1,N-1); b=zeros(1,N-1); c=zeros(1,N-1);
for i=1:N-1
	a(i)=-(1+i/N);
	b(i)=1.5-i/N;
	c(i)=ep;
	f(i)=0;
end;
f(1)=f(1)-y0*b(1);
f(N-1)=f(N-1)-yN*c(N-1);
% solve the tri-diagonal matrix problem
y=tri(a,b,c,f);
y=[y0, y, yN];

plot(x,y,'o','Linewidth',1,'MarkerSize',7)
hold on
plot(x,ya,'--','Linewidth',1)


%say=['\epsilon = ',num2str(ep)];
%text(0.03,-1.2,say,'FontSize',14,'FontWeight','bold')
%text(0.82,1.2,say,'FontSize',14,'FontWeight','bold')

box on
grid on
axis([0 20 -1 3])
loc='NorthEast';
%loc='South';

xlabel('n-axis','FontSize',14,'FontWeight','bold')
ylabel('Solution','FontSize',14,'FontWeight','bold')

set(gca,'FontSize',14);
legend(' Numerical',' Asymptotic','Location',loc);
set(findobj(gcf,'tag','legend'),'FontSize',14); 


% tridiagonal solver
function y = tri( a, b, c, f )
N = length(f);
v = zeros(1,N);   
y = v;
w = a(1);
y(1) = f(1)/w;
for i=2:N
    v(i-1) = c(i-1)/w;
    w = a(i) - b(i)*v(i-1);
    y(i) = ( f(i) - b(i)*y(i-1) )/w;
end
for j=N-1:-1:1
   y(j) = y(j) - v(j)*y(j+1);
end



