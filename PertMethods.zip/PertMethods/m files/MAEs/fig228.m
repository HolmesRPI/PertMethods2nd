function fig228

clf

% r-axis  Exact
load exactdata.txt
re=exactdata(:,1);
ue=exactdata(:,2);

% r-axis  Asymptotic
load asydata.txt
ra=asydata(:,1);
ua=asydata(:,2);

% get(gcf)
set(gcf,'Position', [831 534 599 250]);

plot(re,ue,'--','Linewidth',1)
hold on
box on
grid on
plot(ra,ua,'-','Linewidth',1)

%axis([-1 1 -3 0])
loc='SouthEast';

xlabel('\rho-axis','FontSize',14,'FontWeight','bold')
ylabel('u(x,y)','FontSize',14,'FontWeight','bold')

%set(gca,'xtick',[0 1 2]);
%set(gca,'ytick',[-0.008 -0.003 0.002]);
%set(gca,'XTickLabel',{'0';'t_M';'2t_M'})
%set(gca,'YTickLabel',{'-0.008';'-0.003';'0.002'})

set(gca,'FontSize',14);
legend(' Exact',' Asymptotic','Location',loc);
%set(findobj(gcf,'tag','legend'),'FontSize',14); 

hold off



